/* Seed data — realistic fictional organization (Northwind Labs) */
window.SEED = (function () {
  var levels = [
    { id: 1, label: 'Beginner',   definition: 'New to the skill. Can complete simple tasks with close guidance.' },
    { id: 2, label: 'Developing', definition: 'Can handle routine tasks with occasional support. Still building fluency.' },
    { id: 3, label: 'Intermediate', definition: 'Handles day-to-day work independently. Needs help only on unusual problems.' },
    { id: 4, label: 'Advanced',   definition: 'Solves complex problems and guides others. Work quality others rely on.' },
    { id: 5, label: 'Expert',     definition: 'Sets direction and standards. Recognised authority inside and outside the team.' }
  ];

  var categories = [
    { id: 'tech', name: 'Technical',     blurb: 'Role craft: code, data, systems and tools.' },
    { id: 'beh',  name: 'Behavioral',    blurb: 'How work gets done with others: communication, teamwork, adaptability.' },
    { id: 'mgmt', name: 'Management',    blurb: 'Planning, organising and steering work and resources.' },
    { id: 'lead', name: 'Leadership',    blurb: 'Influence, vision and growing other people.' },
    { id: 'comp', name: 'Compliance',    blurb: 'Rules, security, privacy and ethical standards we uphold.' },
    { id: 'soc',  name: 'Social Impact', blurb: 'Sustainability, inclusion and community contribution.' }
  ];

  var skills = [
    { id: 't1', cat: 'tech', name: 'JavaScript / TypeScript' },
    { id: 't2', cat: 'tech', name: 'System Design' },
    { id: 't3', cat: 'tech', name: 'Cloud & CI/CD' },
    { id: 't4', cat: 'tech', name: 'Data Analysis' },
    { id: 't5', cat: 'tech', name: 'Database Design' },
    { id: 't6', cat: 'tech', name: 'Cybersecurity Basics' },
    { id: 't7', cat: 'tech', name: 'Machine Learning Foundations' },
    { id: 't8', cat: 'tech', name: 'Design Systems & Prototyping' },
    { id: 'b1', cat: 'beh',  name: 'Communication' },
    { id: 'b2', cat: 'beh',  name: 'Teamwork' },
    { id: 'b3', cat: 'beh',  name: 'Adaptability' },
    { id: 'b4', cat: 'beh',  name: 'Time Management' },
    { id: 'b5', cat: 'beh',  name: 'Problem Solving' },
    { id: 'm1', cat: 'mgmt', name: 'Project Management' },
    { id: 'm2', cat: 'mgmt', name: 'Decision Making' },
    { id: 'm3', cat: 'mgmt', name: 'Strategic Planning' },
    { id: 'm4', cat: 'mgmt', name: 'Conflict Resolution' },
    { id: 'l1', cat: 'lead', name: 'Mentoring' },
    { id: 'l2', cat: 'lead', name: 'Team Building' },
    { id: 'l3', cat: 'lead', name: 'Change Management' },
    { id: 'l4', cat: 'lead', name: 'Strategic Vision' },
    { id: 'c1', cat: 'comp', name: 'Data Privacy (GDPR / DPDP)' },
    { id: 'c2', cat: 'comp', name: 'Security Awareness' },
    { id: 'c3', cat: 'comp', name: 'Policy Adherence' },
    { id: 'c4', cat: 'comp', name: 'Risk Awareness' },
    { id: 's1', cat: 'soc',  name: 'Diversity & Inclusion' },
    { id: 's2', cat: 'soc',  name: 'Sustainability Practices' },
    { id: 's3', cat: 'soc',  name: 'Community Engagement' }
  ];

  var roles = [
    { id: 'se',    title: 'Software Engineer',       exp: { t1: 4, t2: 3, t3: 3, b1: 3, b2: 3, b5: 3, c2: 3 }, critical: ['t1', 't2'] },
    { id: 'sr-se', title: 'Senior Software Engineer', exp: { t1: 4, t2: 4, t3: 4, b1: 3, b5: 4, c2: 3, l1: 3, m2: 3 }, critical: ['t1', 't2', 'l1'] },
    { id: 'em',    title: 'Engineering Manager',     exp: { t1: 4, t2: 4, l1: 4, l2: 4, m1: 4, m2: 4, l3: 3, b1: 4 }, critical: ['l1', 'l2', 'm1'] },
    { id: 'da',    title: 'Data Analyst',            exp: { t4: 4, t5: 3, b1: 3, b5: 3, c1: 2, m2: 3 }, critical: ['t4'] },
    { id: 'uxd',   title: 'UI/UX Designer',          exp: { t8: 4, b1: 4, b5: 3, s1: 3, m1: 2 }, critical: ['t8', 'b1'] },
    { id: 'pm',    title: 'Product Manager',         exp: { m1: 4, m2: 4, m3: 3, b1: 4, b5: 4, t4: 3, l4: 3 }, critical: ['m1', 'b1'] },
    { id: 'hr',    title: 'HR Specialist',           exp: { b1: 4, b2: 4, m4: 3, c1: 3, c3: 4, s1: 4, m1: 3 }, critical: ['c3', 's1'] },
    { id: 'mkt',   title: 'Marketing Executive',     exp: { b1: 4, t4: 3, s3: 3, m1: 3, b3: 3, s2: 2 }, critical: ['b1'] },
    { id: 'fin',   title: 'Finance Analyst',         exp: { t4: 4, t5: 3, c3: 4, c4: 4, m2: 3, b1: 3 }, critical: ['c4', 't4'] }
  ];

  var employees = [
    { id: 'EMP-1001', name: 'Ananya Menon',     dept: 'Engineering',     role: 'sr-se', email: 'ananya.menon@northwind.example',  joined: '2021-06-14', managerId: 'EMP-1009' },
    { id: 'EMP-1002', name: 'Rohan Deshpande',  dept: 'Engineering',     role: 'se',    email: 'rohan.deshpande@northwind.example', joined: '2023-02-01', managerId: 'EMP-1009' },
    { id: 'EMP-1003', name: 'Mei Lin Chua',     dept: 'Engineering',     role: 'se',    email: 'meilin.chua@northwind.example',   joined: '2024-08-19', managerId: 'EMP-1009' },
    { id: 'EMP-1009', name: 'Rajesh Iyer',      dept: 'Engineering',     role: 'em',    email: 'rajesh.iyer@northwind.example',   joined: '2019-03-04', managerId: null },
    { id: 'EMP-1015', name: 'Ishita Bose',      dept: 'Product',         role: 'pm',    email: 'ishita.bose@northwind.example',   joined: '2020-01-13', managerId: null },
    { id: 'EMP-1005', name: 'Priya Raghavan',   dept: 'Product',         role: 'pm',    email: 'priya.raghavan@northwind.example', joined: '2022-05-23', managerId: 'EMP-1015' },
    { id: 'EMP-1006', name: 'Tomas Novak',      dept: 'Product',         role: 'da',    email: 'tomas.novak@northwind.example',   joined: '2023-11-06', managerId: 'EMP-1015' },
    { id: 'EMP-1016', name: 'Nadia Fernandes',  dept: 'Design',          role: 'uxd',   email: 'nadia.fernandes@northwind.example', joined: '2019-09-30', managerId: null },
    { id: 'EMP-1007', name: 'Zoya Khan',        dept: 'Design',          role: 'uxd',   email: 'zoya.khan@northwind.example',     joined: '2022-08-08', managerId: 'EMP-1016' },
    { id: 'EMP-1008', name: 'Kabir Sharma',     dept: 'Design',          role: 'uxd',   email: 'kabir.sharma@northwind.example',  joined: '2024-01-15', managerId: 'EMP-1016' },
    { id: 'EMP-1017', name: 'Grace Liu',        dept: 'Marketing',       role: 'mkt',   email: 'grace.liu@northwind.example',     joined: '2021-02-22', managerId: null },
    { id: 'EMP-1010', name: 'Elena Petrova',    dept: 'Marketing',       role: 'mkt',   email: 'elena.petrova@northwind.example', joined: '2023-06-12', managerId: 'EMP-1017' },
    { id: 'EMP-1011', name: 'Arjun Nair',       dept: 'Marketing',       role: 'mkt',   email: 'arjun.nair@northwind.example',    joined: '2025-03-03', managerId: 'EMP-1017' },
    { id: 'EMP-1013', name: 'Vikram Patel',     dept: 'Human Resources', role: 'hr',    email: 'vikram.patel@northwind.example',  joined: '2018-07-09', managerId: null },
    { id: 'EMP-1012', name: 'Farah Ahmed',      dept: 'Human Resources', role: 'hr',    email: 'farah.ahmed@northwind.example',   joined: '2022-10-17', managerId: 'EMP-1013' },
    { id: 'EMP-1004', name: 'Sara Haddad',      dept: 'Finance',         role: 'fin',   email: 'sara.haddad@northwind.example',   joined: '2020-11-02', managerId: null },
    { id: 'EMP-1014', name: 'David Kim',        dept: 'Finance',         role: 'da',    email: 'david.kim@northwind.example',     joined: '2024-04-08', managerId: 'EMP-1004' }
  ];

  function items(map, comments) {
    var out = {};
    Object.keys(map).forEach(function (k) {
      out[k] = { level: map[k], comment: (comments && comments[k]) || '' };
    });
    return out;
  }

  var assessments = [
    {
      id: 'A-2501', employeeId: 'EMP-1001', evaluatorId: 'EMP-1009', cycle: '2026-H1', status: 'submitted',
      createdAt: '2026-03-02', updatedAt: '2026-03-10', submittedAt: '2026-03-10',
      categoryIds: ['tech', 'beh', 'comp', 'lead', 'mgmt'],
      items: items({ t1: 4, t2: 2, t3: 3, b1: 3, b5: 3, c2: 3, l1: 2, m2: 2 }),
      summary: 'Strong individual contributor; readiness for broader ownership visible but not yet practiced.'
    },
    {
      id: 'A-2601', employeeId: 'EMP-1001', evaluatorId: 'EMP-1009', cycle: '2026-H2', status: 'submitted',
      createdAt: '2026-09-05', updatedAt: '2026-09-12', submittedAt: '2026-09-12',
      categoryIds: ['tech', 'beh', 'comp', 'lead', 'mgmt'],
      items: items({
        t1: 4, t2: 3, t3: 4, b1: 3, b5: 4, c2: 3, l1: 2, m2: 3
      }, {
        t1: 'Consistently produces clean, well-tested TypeScript; sets the bar in code review.',
        t2: 'Designed the billing service split well, but leaned on peer review for trade-off decisions.',
        l1: 'Paused in mentoring sessions; mentee feedback asks for more structured check-ins.',
        b5: 'Untangled the migration incident with minimal escalation — excellent judgement.'
      }),
      summary: 'Ananya is operating at level in every technical area and above expectation in problem solving. The development edge is people multiplication: mentoring is currently one level below role expectation and should be the focus of this cycle.'
    },
    {
      id: 'A-2602', employeeId: 'EMP-1002', evaluatorId: 'EMP-1009', cycle: '2026-H2', status: 'draft',
      createdAt: '2026-09-15', updatedAt: '2026-09-17', submittedAt: null,
      categoryIds: ['tech', 'beh', 'comp'],
      items: items({ t1: 3, t2: 2, t3: 3, b1: 3 }, {
        t1: 'Solid feature work; still avoids writing tests first.',
        t2: 'Needs support scoping non-functional requirements.'
      }),
      summary: ''
    },
    {
      id: 'A-2502', employeeId: 'EMP-1005', evaluatorId: 'EMP-1015', cycle: '2026-H1', status: 'submitted',
      createdAt: '2026-03-04', updatedAt: '2026-03-12', submittedAt: '2026-03-12',
      categoryIds: ['mgmt', 'beh', 'tech', 'lead'],
      items: items({ m1: 3, m2: 3, m3: 2, b1: 3, b5: 3, t4: 2, l4: 2 }),
      summary: 'Reliable delivery owner; strategic muscle still forming.'
    },
    {
      id: 'A-2603', employeeId: 'EMP-1005', evaluatorId: 'EMP-1015', cycle: '2026-H2', status: 'submitted',
      createdAt: '2026-08-20', updatedAt: '2026-08-28', submittedAt: '2026-08-28',
      categoryIds: ['mgmt', 'beh', 'tech', 'lead'],
      items: items({ m1: 4, m2: 3, m3: 2, b1: 4, b5: 3, t4: 3, l4: 2 }, {
        m1: 'Ran the mobile launch flawlessly — scope, comms and risks all handled.',
        m3: 'Quarterly plan needed three revisions; strategy framing is the growth area.',
        b1: 'Stakeholder updates are crisp; exec reviews went well.'
      }),
      summary: 'Priya has grown into a strong delivery leader this half. Strategic planning remains two levels below expectation and is the priority for the next cycle, with a planned planning rotation.'
    },
    {
      id: 'A-2604', employeeId: 'EMP-1007', evaluatorId: 'EMP-1016', cycle: '2026-H2', status: 'draft',
      createdAt: '2026-09-14', updatedAt: '2026-09-15', submittedAt: null,
      categoryIds: ['tech', 'beh', 'soc'],
      items: items({ t8: 3, b1: 3 }),
      summary: ''
    },
    {
      id: 'A-2605', employeeId: 'EMP-1014', evaluatorId: 'EMP-1004', cycle: '2026-H2', status: 'submitted',
      createdAt: '2026-09-06', updatedAt: '2026-09-10', submittedAt: '2026-09-10',
      categoryIds: ['tech', 'beh', 'comp', 'mgmt'],
      items: items({ t4: 3, t5: 2, b1: 3, b5: 3, c1: 2, m2: 2 }, {
        t5: 'Joins and indexing still cause slow reports; pairing scheduled with Sara.',
        t4: 'Dashboard work for the Q3 review was accurate and on time.'
      }),
      summary: 'David delivers reliable analysis work. Database depth is the clear next step; a guided SQL track is recommended before the year-end reporting push.'
    }
  ];

  var recommendations = [
    { id: 'R-01', assessmentId: 'A-2601', employeeId: 'EMP-1001', skillId: 'l1', current: 2, expected: 3, action: 'Lead a mentoring circle for two junior engineers this cycle', type: 'Mentorship', priority: 'High', weeks: 8, status: 'In Progress', due: '2026-11-15' },
    { id: 'R-02', assessmentId: 'A-2601', employeeId: 'EMP-1001', skillId: 't2', current: 3, expected: 4, action: 'Architecture design clinic — modules 3 and 4', type: 'Training', priority: 'Medium', weeks: 4, status: 'Not Started', due: '2026-12-01' },
    { id: 'R-03', assessmentId: 'A-2603', employeeId: 'EMP-1005', skillId: 'm3', current: 2, expected: 3, action: 'Strategy rotation: co-own H1 planning with Head of Product', type: 'Stretch assignment', priority: 'High', weeks: 10, status: 'In Progress', due: '2026-12-20' },
    { id: 'R-04', assessmentId: 'A-2603', employeeId: 'EMP-1005', skillId: 'l4', current: 2, expected: 3, action: 'Executive presence workshop (two days)', type: 'Training', priority: 'Low', weeks: 2, status: 'Completed', due: '2026-09-01' },
    { id: 'R-05', assessmentId: 'A-2605', employeeId: 'EMP-1014', skillId: 't5', current: 2, expected: 3, action: 'SQL for analysts — guided track with weekly pairing', type: 'Training', priority: 'Medium', weeks: 6, status: 'Not Started', due: '2026-11-30' }
  ];

  var events = [
    { date: '2026-09-17', type: 'assessment', text: 'Rajesh Iyer continued Rohan Deshpande’s assessment (draft, 4 of 7 skills rated)' },
    { date: '2026-09-12', type: 'assessment', text: 'Assessment submitted for Ananya Menon by Rajesh Iyer' },
    { date: '2026-09-12', type: 'rec',        text: 'Development plan updated for Ananya Menon — 2 recommendations added' },
    { date: '2026-09-10', type: 'assessment', text: 'Assessment submitted for David Kim by Sara Haddad' },
    { date: '2026-09-08', type: 'skill',      text: 'Skill “Machine Learning Foundations” added to Technical' },
    { date: '2026-09-05', type: 'profile',    text: 'Kabir Sharma’s profile updated — title confirmed as UI/UX Designer' },
    { date: '2026-08-28', type: 'assessment', text: 'Assessment submitted for Priya Raghavan by Ishita Bose' }
  ];

  return {
    version: 1,
    viewAs: 'evaluator',
    cycle: '2026-H2',
    levels: levels,
    categories: categories,
    skills: skills,
    roles: roles,
    employees: employees,
    assessments: assessments,
    recommendations: recommendations,
    events: events
  };
})();
