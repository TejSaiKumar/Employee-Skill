/* Employees — searchable, filterable wall + add/edit */
Pages.people = (function () {
  var PAGE = 12;
  var f = { q: '', dept: '', role: '', status: '', level: '', sort: 'name', gapsonly: false, shown: PAGE };

  function statusOf(e) {
    var a = Store.latestAssessment(e.id);
    if (!a) return 'none';
    return a.status === 'submitted' && a.cycle === Store.state.cycle ? 'done' : (a.status === 'draft' ? 'draft' : 'none');
  }

  function filtered() {
    var list = Store.state.employees.filter(function (e) {
      var r = Store.role(e.role);
      if (f.q && (e.name + ' ' + e.id + ' ' + e.dept + ' ' + (r ? r.title : '')).toLowerCase().indexOf(f.q.toLowerCase()) === -1) return false;
      if (f.dept && e.dept !== f.dept) return false;
      if (f.role && e.role !== f.role) return false;
      if (f.level) {
        var a2 = Store.latestAssessment(e.id, true);
        if (f.level === 'none') { if (a2) return false; }
        else {
          if (!a2) return false;
          var vals = Object.keys(a2.items).map(function (k) { return a2.items[k].level; }).filter(Boolean);
          var avg = vals.length ? vals.reduce(function (x, y) { return x + y; }, 0) / vals.length : 0;
          if (f.level === 'high' && avg < 4) return false;
          if (f.level === 'mid' && (avg < 3 || avg >= 4)) return false;
          if (f.level === 'low' && avg >= 3) return false;
        }
      }
      if (f.status && statusOf(e) !== f.status) return false;
      if (f.gapsonly && Store.openGaps(e.id).length === 0) return false;
      return true;
    });
    list.sort(function (a, b) {
      if (f.sort === 'dept') return a.dept.localeCompare(b.dept) || a.name.localeCompare(b.name);
      if (f.sort === 'gaps') return Store.openGaps(b.id).length - Store.openGaps(a.id) || a.name.localeCompare(b.name);
      if (f.sort === 'recent') {
        var da = Store.latestAssessment(a.id), db = Store.latestAssessment(b.id);
        return ((db && (db.submittedAt || db.updatedAt)) || '').localeCompare((da && (da.submittedAt || da.updatedAt)) || '');
      }
      return a.name.localeCompare(b.name);
    });
    return list;
  }

  function cardHTML(e) {
    var r = Store.role(e.role);
    var gaps = Store.openGaps(e.id);
    var st = statusOf(e);
    var a = Store.latestAssessment(e.id);
    var cov = a ? Store.coverage(a) : null;
    var statusLine = st === 'done' ? 'Assessed ' + UI.fmtDate(a.submittedAt) : st === 'draft' ? 'Draft · updated ' + UI.fmtDate(a.updatedAt) : 'Not assessed this cycle';
    return '<article class="card pad-sm clickable person" data-go="#/people/' + e.id + '" tabindex="0" role="link" aria-label="Open profile of ' + UI.esc(e.name) + '">' +
      '<div class="top">' + UI.avatar(e) + '<div style="min-width:0;flex:1"><div class="nm" title="' + UI.esc(e.name) + '">' + UI.esc(e.name) + '</div><div class="rl" title="' + UI.esc((r ? r.title : '') + ' · ' + e.dept) + '">' + UI.esc(r ? r.title : '—') + ' · ' + UI.esc(e.dept) + '</div></div></div>' +
      (cov ? UI.progress(cov.rated, cov.total, 'slim') : '<div class="progress slim"><i style="width:0"></i></div><span class="t-caption mut">0 of ' + Store.expectations(e.id).length + ' skills rated</span>') +
      '<div class="row wrap" style="margin-top:10px">' +
      (gaps.length ? UI.chip(gaps.length + ' gap' + (gaps.length > 1 ? 's' : ''), gaps.some(function (g) { return g.sev === 'critical'; }) ? 'chip-error' : 'chip-warning', true) : UI.chip('On track', 'chip-success', true, 'check')) +
      (st === 'done' ? UI.chipAssessStatus('submitted') : st === 'draft' ? UI.chipAssessStatus('draft') : UI.chip('Not started', 'chip-neutral', true)) +
      '</div>' +
      '<div class="t-caption mut" style="margin-top:8px">' + statusLine + '</div>' +
      '</article>';
  }

  function listHTML() {
    var list = filtered();
    var shown = list.slice(0, f.shown);
    if (!list.length) {
      return UI.empty('search', 'No employees match', 'Try clearing the search or filters to see the whole team.',
        '<button class="btn btn-secondary sm" data-clear>Clear filters</button>');
    }
    var html = '<div class="wall">' + shown.map(cardHTML).join('') + '</div>';
    if (list.length > shown.length) html += '<div class="loadmore"><button class="btn btn-secondary" data-more>Load more (' + (list.length - shown.length) + ' remaining)</button></div>';
    return html;
  }

  function barHTML() {
    var depts = Store.departments();
    return '<div class="filterbar" role="search">' +
      '<span class="grow"><input class="input" id="pq" type="search" placeholder="Search name, ID, role…" value="' + UI.esc(f.q) + '" aria-label="Search employees"></span>' +
      '<select class="select" id="pdept" aria-label="Filter by department"><option value="">All departments</option>' + depts.map(function (d) { return '<option' + (f.dept === d ? ' selected' : '') + '>' + UI.esc(d) + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="prole" aria-label="Filter by role"><option value="">All roles</option>' + Store.state.roles.map(function (r) { return '<option value="' + r.id + '"' + (f.role === r.id ? ' selected' : '') + '>' + UI.esc(r.title) + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="plevel" aria-label="Filter by overall skill level"><option value="">Any skill level</option><option value="high"' + (f.level === 'high' ? ' selected' : '') + '>Advanced+ (4–5)</option><option value="mid"' + (f.level === 'mid' ? ' selected' : '') + '>Intermediate (3–3.9)</option><option value="low"' + (f.level === 'low' ? ' selected' : '') + '>Below 3</option><option value="none"' + (f.level === 'none' ? ' selected' : '') + '>Not assessed</option></select>' +
      '<select class="select" id="pstatus" aria-label="Filter by assessment status"><option value="">Any status</option><option value="done"' + (f.status === 'done' ? ' selected' : '') + '>Assessed this cycle</option><option value="draft"' + (f.status === 'draft' ? ' selected' : '') + '>Draft in progress</option><option value="none"' + (f.status === 'none' ? ' selected' : '') + '>Not started</option></select>' +
      '<select class="select" id="psort" aria-label="Sort employees"><option value="name">Sort: Name A–Z</option><option value="dept"' + (f.sort === 'dept' ? ' selected' : '') + '>Sort: Department</option><option value="gaps"' + (f.sort === 'gaps' ? ' selected' : '') + '>Sort: Most gaps</option><option value="recent"' + (f.sort === 'recent' ? ' selected' : '') + '>Sort: Recently assessed</option></select>' +
      '<label class="switch"><input type="checkbox" id="pgaps"' + (f.gapsonly ? ' checked' : '') + '><span class="track" aria-hidden="true"></span>Gaps only</label>' +
      '<span class="count" id="pcount"></span>' +
      '</div>';
  }

  function formModal(existing) {
    var depts = Store.departments().concat(['Operations', 'Legal']);
    var body =
      '<div class="field"><label for="ef-name">Full name <span class="mut">(required)</span></label><input class="input" id="ef-name" value="' + UI.esc(existing ? existing.name : '') + '" autocomplete="off"><span class="error-msg" hidden></span></div>' +
      '<div class="row wrap"><div class="field grow"><label for="ef-dept">Department <span class="mut">(required)</span></label><select class="select" id="ef-dept"><option value="">Select…</option>' + depts.map(function (d) { return '<option' + (existing && existing.dept === d ? ' selected' : '') + '>' + UI.esc(d) + '</option>'; }).join('') + '</select><span class="error-msg" hidden></span></div>' +
      '<div class="field grow"><label for="ef-role">Job role <span class="mut">(required)</span></label><select class="select" id="ef-role"><option value="">Select…</option>' + Store.state.roles.map(function (r) { return '<option value="' + r.id + '"' + (existing && existing.role === r.id ? ' selected' : '') + '>' + UI.esc(r.title) + '</option>'; }).join('') + '</select><span class="error-msg" hidden></span></div></div>' +
      '<div class="field"><label for="ef-email">Work email <span class="mut">(required)</span></label><input class="input" id="ef-email" type="email" value="' + UI.esc(existing ? existing.email : '') + '" placeholder="name@northwind.example"><span class="error-msg" hidden></span></div>' +
      '<div class="row wrap"><div class="field grow"><label for="ef-joined">Joining date</label><input class="input" id="ef-joined" type="date" value="' + UI.esc(existing ? existing.joined : '') + '"></div>' +
      '<div class="field grow"><label for="ef-mgr">Manager</label><select class="select" id="ef-mgr"><option value="">None (exec team)</option>' + Store.state.employees.filter(function (e) { return !existing || e.id !== existing.id; }).map(function (e) { return '<option value="' + e.id + '"' + (existing && existing.managerId === e.id ? ' selected' : '') + '>' + UI.esc(e.name) + '</option>'; }).join('') + '</select></div></div>';
    UI.openModal({
      title: existing ? 'Edit employee' : 'Add employee',
      body: body,
      footer: '<button class="btn btn-ghost" data-cancel>Cancel</button><button class="btn btn-primary" data-save>' + (existing ? 'Save changes' : 'Add employee') + '</button>',
      onMount: function (panel, close) {
        panel.querySelector('[data-cancel]').addEventListener('click', close);
        panel.querySelector('[data-save]').addEventListener('click', function () {
          var name = panel.querySelector('#ef-name'), dept = panel.querySelector('#ef-dept'), role = panel.querySelector('#ef-role'), email = panel.querySelector('#ef-email');
          var ok = true;
          function err(input, msg) {
            var field = input.closest('.field'), span = field.querySelector('.error-msg');
            field.classList.toggle('has-error', !!msg);
            span.hidden = !msg; span.textContent = msg || '';
            input.setAttribute('aria-invalid', msg ? 'true' : 'false');
            if (msg) ok = false;
          }
          err(name, name.value.trim() ? '' : 'Name is required.');
          err(dept, dept.value ? '' : 'Choose a department.');
          err(role, role.value ? '' : 'Choose a role.');
          err(email, /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim()) ? '' : 'Enter a valid work email.');
          if (!ok) return;
          Store.mutate(function (s) {
            if (existing) {
              existing.name = name.value.trim(); existing.dept = dept.value; existing.role = role.value;
              existing.email = email.value.trim(); existing.joined = panel.querySelector('#ef-joined').value || existing.joined;
              existing.managerId = panel.querySelector('#ef-mgr').value || null;
              s.events.unshift({ date: new Date().toISOString().slice(0, 10), type: 'profile', text: existing.name + '’s profile updated' });
            } else {
              var id = Store.nextId('EMP-', s.employees.map(function (e) { return { id: e.id.replace('EMP-', 'EMP-0') }; }));
              id = 'EMP-' + (1000 + s.employees.length + 1);
              while (s.employees.some(function (e) { return e.id === id; })) id = 'EMP-' + (parseInt(id.slice(4), 10) + 1);
              s.employees.push({
                id: id, name: name.value.trim(), dept: dept.value, role: role.value, email: email.value.trim(),
                joined: panel.querySelector('#ef-joined').value || new Date().toISOString().slice(0, 10),
                managerId: panel.querySelector('#ef-mgr').value || null
              });
              s.events.unshift({ date: new Date().toISOString().slice(0, 10), type: 'profile', text: name.value.trim() + ' added to ' + dept.value + ' (' + id + ')' });
            }
          });
          close();
          UI.toast(existing ? 'Profile saved.' : 'Employee added — ready for assessment.', 'success');
          Router.render();
        });
      }
    });
  }

  function render(params) {
    if (params && params.dept) f.dept = params.dept;
    if (params && params.role) f.role = params.role;
    if (params && params.q) f.q = params.q;
    f.shown = PAGE;
    var canEdit = Store.state.viewAs !== 'employee';
    var html = '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Employees</h1><p class="sec">Everyone in the organization, with assessment and gap status at a glance.</p></div>' +
      (canEdit ? '<button class="btn btn-primary" id="addemp">' + UI.icon('plus', 16) + ' Add employee</button>' : '') + '</div>' +
      barHTML() + '<div id="plist"></div></div>';
    return {
      title: 'Employees', html: html,
      mount: function (root) {
        function refresh() {
          var list = filtered();
          root.querySelector('#pcount').textContent = 'Showing ' + Math.min(f.shown, list.length) + ' of ' + list.length;
          root.querySelector('#plist').innerHTML = listHTML();
        }
        UI.withLatency('people', root, function (loading) {
          if (loading) {
            root.querySelector('#plist').innerHTML = '<div class="wall">' + UI.skPerson() + UI.skPerson() + UI.skPerson() + UI.skPerson() + '</div>';
            return;
          }
          refresh();
        });
        root.querySelector('#pq').addEventListener('input', UI.debounce(function (e) { f.q = e.target.value; f.shown = PAGE; refresh(); }, 200));
        root.querySelector('#pdept').addEventListener('change', function (e) { f.dept = e.target.value; f.shown = PAGE; refresh(); });
        root.querySelector('#prole').addEventListener('change', function (e) { f.role = e.target.value; f.shown = PAGE; refresh(); });
        root.querySelector('#plevel').addEventListener('change', function (e) { f.level = e.target.value; f.shown = PAGE; refresh(); });
        root.querySelector('#pstatus').addEventListener('change', function (e) { f.status = e.target.value; f.shown = PAGE; refresh(); });
        root.querySelector('#psort').addEventListener('change', function (e) { f.sort = e.target.value; refresh(); });
        root.querySelector('#pgaps').addEventListener('change', function (e) { f.gapsonly = e.target.checked; f.shown = PAGE; refresh(); });
        root.querySelector('#plist').addEventListener('click', function (e) {
          var card = e.target.closest('[data-go]');
          if (card) { location.hash = card.dataset.go; return; }
          if (e.target.closest('[data-more]')) { f.shown += PAGE; refresh(); return; }
          if (e.target.closest('[data-clear]')) { f = { q: '', dept: '', role: '', status: '', level: '', sort: 'name', gapsonly: false, shown: PAGE }; Router.render(); }
        });
        root.querySelector('#plist').addEventListener('keydown', function (e) {
          var card = e.target.closest('[data-go]');
          if (card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); location.hash = card.dataset.go; }
        });
        var add = root.querySelector('#addemp');
        if (add) add.addEventListener('click', function () { formModal(null); });
      }
    };
  }
  return { render: render, formModal: formModal };
})();
