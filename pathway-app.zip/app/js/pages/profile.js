/* Employee profile — story layout with growth map, chapters, development, history */
Pages.profile = (function () {
  function nextReviewDate(a) {
    if (!a || !a.submittedAt) return null;
    var d = new Date(a.submittedAt);
    d.setMonth(d.getMonth() + 6);
    return d.toISOString().slice(0, 10);
  }
  function prevSubmitted(empId, beforeId) {
    var list = Store.assessmentsFor(empId).filter(function (a) { return a.status === 'submitted' && a.id !== beforeId; });
    return list[0] || null;
  }
  function avgOf(a) {
    var vals = Object.keys(a.items).map(function (k) { return a.items[k].level; }).filter(Boolean);
    if (!vals.length) return null;
    return Math.round(vals.reduce(function (x, y) { return x + y; }, 0) / vals.length * 10) / 10;
  }

  function journeyHTML(empId) {
    var last = Store.latestAssessment(empId, true);
    var next = nextReviewDate(last);
    return '<div class="stepper" role="list" aria-label="Assessment journey">' +
      '<span class="st done" role="listitem" aria-label="Last assessment ' + (last ? UI.fmtDate(last.submittedAt) : 'none') + '"></span><span class="bar done"></span>' +
      '<span class="st cur" role="listitem" aria-label="Today"></span><span class="bar"></span>' +
      '<span class="st" role="listitem" aria-label="Next review ' + (next ? UI.fmtDate(next) : 'not scheduled') + '"></span></div>' +
      '<div class="row spread" style="margin-top:6px"><span class="t-caption mut">' + (last ? 'Assessed ' + UI.fmtDate(last.submittedAt) : 'Not assessed yet') + '</span><span class="t-caption" style="color:var(--accent-ink);font-weight:600">today</span><span class="t-caption mut">' + (next ? 'Next review ' + UI.fmtDate(next) : 'Next review not scheduled') + '</span></div>';
  }

  function shelvesHTML(empId) {
    var gaps = Store.gapsFor(empId).gaps;
    var strong = gaps.filter(function (g) { return g.gap <= 0 && g.current >= 4; }).slice(0, 5);
    var focus = Store.openGaps(empId).slice(0, 5);
    var sugg = Store.suggestionsFor(empId);
    function row(g, withSugg) {
      var s = Store.skill(g.skillId);
      var sg = sugg.filter(function (x) { return x.skillId === g.skillId; })[0];
      return '<li style="padding:10px 0;border-top:1px solid var(--border)"><div class="row wrap" style="justify-content:space-between"><span class="t-sm" style="font-weight:600">' + UI.esc(s.name) + '</span>' + UI.chipCat(s.cat, true) + '</div>' +
        (withSugg ? '<div style="margin-top:4px">' + UI.gapLine(g.current, g.expected, g.sev) + '</div>' + (sg ? '<p class="t-caption mut" style="margin:4px 0 0">Suggested: ' + UI.esc(sg.action) + '</p>' : '') : '<p class="t-caption mut" style="margin:4px 0 0">' + UI.levelWord(g.current) + ' · ' + UI.esc(UI.gapSentence(g.gap, g.sev)) + '</p>') + '</li>';
    }
    return '<div class="dash-cols">' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Strengths</h2>' + UI.chip(String(strong.length), 'chip-success', true) + '</div>' +
      (strong.length ? '<ul>' + strong.map(function (g) { return row(g, false); }).join('') + '</ul>' : UI.empty('check', 'No strengths recorded yet', 'Skills rated Advanced or above with met expectations appear here.')) + '</article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Focus areas</h2>' + UI.chip(String(focus.length), focus.some(function (g) { return g.sev === 'critical'; }) ? 'chip-error' : 'chip-warning', true) + '</div>' +
      (focus.length ? '<ul>' + focus.map(function (g) { return row(g, true); }).join('') + '</ul>' : UI.empty('check', 'All skills meet role expectations', 'No gaps recorded for this employee.')) + '</article></div>';
  }

  function growthTopHTML(empId) {
    var e = Store.emp(empId);
    var vals = UI.catAveragesFor(empId, true) || UI.catAveragesFor(empId, false);
    var a = Store.latestAssessment(empId);
    var cov = a ? Store.coverage(a) : { rated: 0, total: Store.expectations(empId).length, pct: 0 };
    var status = a ? (a.status === 'submitted' ? UI.chipAssessStatus('submitted') : UI.chipAssessStatus('draft')) : UI.chip('Not started', 'chip-neutral', true);
    var view = Store.state.viewAs;
    var cta = '';
    if (view === 'employee') cta = '<a class="btn btn-primary" href="#/reports">View my reports</a>';
    else if (a && a.status === 'draft') cta = '<a class="btn btn-primary" href="#/assess/' + a.id + '">Continue assessment</a>';
    else if (a && a.status === 'submitted') cta = '<a class="btn btn-secondary" href="#/report/employee/' + e.id + '">View latest report</a><button class="btn btn-primary" data-start>New assessment</button>';
    else cta = '<button class="btn btn-primary" data-start>Start assessment</button>';
    return '<div class="growth-top">' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Competency wheel</h2></div>' + UI.wheel(vals, 240) +
      '<div class="row wrap" style="justify-content:center;margin-top:8px">' + Store.state.categories.map(function (c) { return UI.chipCat(c.id, true); }).join(' ') + '</div></article>' +
      '<article class="card"><div class="card-head"><span class="grow"><h2 class="t-h2">Now &amp; next</h2></span>' + status + '</div>' +
      '<dl class="report metagrid" style="margin:0 0 12px"><div><dt>Evaluator</dt><dd>' + UI.esc(a && a.evaluatorId ? (Store.emp(a.evaluatorId) || {}).name || '—' : 'Not assigned') + '</dd></div>' +
      '<div><dt>Cycle</dt><dd>' + UI.esc(Store.state.cycle) + '</dd></div>' +
      '<div><dt>Last assessment</dt><dd>' + UI.fmtDate(a ? (a.submittedAt || a.updatedAt) : null) + '</dd></div></dl>' +
      '<div class="stack" style="gap:6px">' + UI.progress(cov.rated, cov.total) + '</div>' +
      '<h3 class="t-h3" style="margin:16px 0 6px">Journey</h3>' + journeyHTML(empId) +
      '<div class="row wrap" style="margin-top:16px">' + cta + '</div></article></div>';
  }

  function growthPage(empId) {
    var e = Store.emp(empId);
    return '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">My growth</h1><p class="sec">' + UI.esc(e.name) + ' · ' + UI.esc(Store.role(e.role).title) + ' · ' + UI.esc(e.dept) + '</p></div></div>' +
      growthTopHTML(empId) + shelvesHTML(empId) + '</div>';
  }

  function chaptersHTML(empId) {
    var a = Store.latestAssessment(empId);
    var items = a ? Store.itemsList(a) : [];
    var prev = a ? prevSubmitted(empId, a.id) : null;
    var prevItems = prev ? Store.itemsList(prev) : [];
    var html = '';
    Store.state.categories.forEach(function (c) {
      var rows = Store.expectations(empId).filter(function (x) { return Store.skill(x.skillId).cat === c.id; });
      if (!rows.length) return;
      var rated = rows.filter(function (x) { return items.some(function (i) { return i.skillId === x.skillId && i.level; }); }).length;
      html += '<article class="card chapter"><div class="card-head">' + UI.chipCat(c.id) +
        '<span class="grow"><h3 class="t-h3">' + UI.esc(c.name) + '</h3><p class="t-caption mut">' + UI.esc(c.blurb) + '</p></span>' +
        '<span class="t-caption mut">' + rated + '/' + rows.length + ' rated</span></div>';
      html += rows.map(function (x) {
        var s = Store.skill(x.skillId);
        var it = items.filter(function (i) { return i.skillId === x.skillId; })[0];
        var pit = prevItems.filter(function (i) { return i.skillId === x.skillId; })[0];
        var cur = it && it.level ? it.level : null;
        var sev = cur ? Store.sevOf(x.expected - cur, x.critical) : null;
        return '<div class="skillrow"><div><div class="nm" title="' + UI.esc(s.name) + '">' + UI.esc(s.name) + '</div>' +
          '<span class="t-caption mut">' + (cur ? 'Last assessed ' + UI.fmtDate(a.submittedAt || a.updatedAt) : 'Not yet assessed') + '</span></div>' +
          '<div class="meta">' + (pit && pit.level && cur ? UI.spark(pit.level, cur) : '') + UI.dotsRead(cur, x.expected) + '<span class="dotword">' + UI.levelWord(cur) + '</span></div>' +
          (cur ? '<div class="gapcell">' + UI.gapLine(cur, x.expected, sev) + (x.critical ? ' ' + UI.chip('Role-critical', 'chip-neutral', true) : '') + '</div>' : '<div class="gapcell"><span class="t-caption mut">Awaiting first rating — role expects ' + UI.levelWord(x.expected) + '.</span></div>') +
          '</div>';
      }).join('');
      html += '</article>';
    });
    return html || UI.empty('doc', 'No role expectations configured', 'Add expected skills for this role in Settings to see skill chapters.');
  }

  function developmentHTML(empId) {
    var gaps = Store.openGaps(empId);
    var recs = Store.recsFor(empId);
    var sugg = Store.suggestionsFor(empId);
    var canEdit = Store.state.viewAs !== 'employee';
    var gapsList = gaps.length ? '<ul>' + gaps.map(function (g) {
      var s = Store.skill(g.skillId);
      return '<li style="padding:10px 0;border-top:1px solid var(--border)"><div class="row wrap" style="justify-content:space-between;gap:8px"><span class="t-sm" style="font-weight:600">' + UI.esc(s.name) + '</span>' + UI.chipSev(g.sev) + '</div><div style="margin-top:6px">' + UI.gapLine(g.current, g.expected, g.sev) + '</div></li>';
    }).join('') + '</ul>' : UI.empty('check', 'No open gaps', 'Every assessed skill meets or exceeds role expectation.');
    var recsList = recs.length ? '<ul>' + recs.map(function (r) {
      var s = Store.skill(r.skillId);
      return '<li class="recrow"><div><div class="t-sm" style="font-weight:600">' + UI.esc(r.action) + '</div>' +
        '<div class="meta" style="margin-top:6px">' + UI.chipCat(s.cat, true) + UI.chip(r.type, 'chip-accent', true) + UI.chipPriority(r.priority) + UI.chipRecStatus(r.status) +
        '<span class="t-caption mut">' + UI.levelWord(r.current) + ' → ' + UI.levelWord(r.expected) + ' · ' + r.weeks + ' wks · due ' + UI.fmtDate(r.due) + '</span></div></div></li>';
    }).join('') + '</ul>' : UI.empty('flag', 'No development plan yet', 'Recommendations appear here after an assessment, or add suggested actions below.');
    var suggList = canEdit && sugg.length ? '<h3 class="t-h3" style="margin:16px 0 6px">Suggested from current gaps</h3><ul>' + sugg.map(function (sg, i) {
      return '<li class="recrow"><div><div class="t-sm" style="font-weight:600">' + UI.esc(sg.action) + '</div>' +
        '<div class="meta" style="margin-top:6px">' + UI.chipCat(Store.skill(sg.skillId).cat, true) + UI.chip(sg.type, 'chip-accent', true) + UI.chipPriority(sg.priority) + '<span class="t-caption mut">gap ' + sg.gap + ' lvl · ~' + sg.weeks + ' wks</span></div></div>' +
        '<div class="ctl"><button class="btn sm btn-secondary" data-add="' + i + '">' + UI.icon('plus', 14) + ' Add to plan</button></div></li>';
    }).join('') + '</ul>' : '';
    return '<div class="profile-grid"><article class="card"><div class="card-head"><h2 class="t-h2">Skill gaps</h2>' + UI.chip(String(gaps.length), gaps.length ? 'chip-warning' : 'chip-success', true) + '</div>' + gapsList + '</article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Development plan</h2>' + UI.chip(String(recs.length), 'chip-info', true) + '</div>' + recsList + suggList + '</article></div>';
  }

  function historyHTML(empId) {
    var list = Store.assessmentsFor(empId);
    if (!list.length) return UI.empty('cal', 'No assessments yet', 'Once an assessment is started, its history appears here.');
    return '<ol class="timeline">' + list.map(function (a) {
      var prev = prevSubmitted(empId, a.id);
      var cur = avgOf(a), pv = prev ? avgOf(prev) : null;
      return '<li class="' + (a.status === 'submitted' ? 'sub' : '') + '"><div class="row wrap" style="gap:8px"><span class="t-sm" style="font-weight:600">' + UI.esc(a.cycle) + '</span>' + UI.chipAssessStatus(a.status) +
        (a.status === 'submitted' ? '<a class="t-sm" href="#/report/employee/' + empId + '">View report</a>' : '<a class="t-sm" href="#/assess/' + a.id + '">Continue draft</a>') + '</div>' +
        '<p class="t-caption mut" style="margin:2px 0 0">' + UI.fmtDate(a.submittedAt || a.updatedAt) + ' · ' + UI.esc(a.evaluatorId ? (Store.emp(a.evaluatorId) || {}).name : '—') + ' · overall ' + (cur == null ? '—' : cur + '/5') + ' ' + (cur != null && pv != null ? UI.spark(pv, cur) : '') + '</p></li>';
    }).join('') + '</ol>';
  }

  function render(params) {
    var e = Store.emp(params.id);
    if (!e) return { title: 'Not found', html: '<div class="container">' + UI.empty('user', 'Employee not found', 'This profile does not exist in the demo data.', '<a class="btn btn-secondary sm" href="#/people">Back to employees</a>') + '</div>' };
    if (Store.state.viewAs === 'employee' && e.id !== DEMO_SELF) {
      return { title: 'My growth', html: growthPage(DEMO_SELF) };
    }
    var r = Store.role(e.role);
    var html = '<div class="container">' +
      '<header class="card profilehead">' +
      '<div class="id">' + UI.avatar(e, 'xl') + '<div style="min-width:0"><h1 class="t-title">' + UI.esc(e.name) + '</h1>' +
      '<p class="sec">' + UI.esc(r.title) + ' · ' + UI.esc(e.dept) + '</p>' +
      '<div class="row wrap" style="margin-top:8px">' + UI.chip(e.id, 'chip-neutral', true) + (Store.openGaps(e.id).length ? UI.chip(Store.openGaps(e.id).length + ' open gaps', 'chip-warning', true) : UI.chip('On track', 'chip-success', true, 'check')) + '</div></div></div>' +
      '<dl class="meta-grid"><div><dt>Employee ID</dt><dd class="t-mono">' + UI.esc(e.id) + '</dd></div><div><dt>Email</dt><dd title="' + UI.esc(e.email) + '">' + UI.esc(e.email) + '</dd></div><div><dt>Joined</dt><dd>' + UI.fmtDate(e.joined) + '</dd></div><div><dt>Manager</dt><dd>' + UI.esc(Store.managerName(e)) + '</dd></div></dl>' +
      '<div class="profile-actions" id="pactions"></div>' +
      '</header>' +
      '<nav class="chipnav" aria-label="Profile sections"><a class="chip chipbtn" href="#skills" data-anchor="skills">Skills</a><a class="chip chipbtn" href="#development" data-anchor="development">Development</a><a class="chip chipbtn" href="#history" data-anchor="history">History</a></nav>' +
      '<div id="pgrowth"></div>' +
      '<section class="section" id="skills"><h2 class="t-h2" style="margin-bottom:12px">Skill chapters</h2><div id="pchapters"></div></section>' +
      '<section class="section" id="development"><h2 class="t-h2" style="margin-bottom:12px">Development</h2><div id="pdev"></div></section>' +
      '<section class="section" id="history"><h2 class="t-h2" style="margin-bottom:12px">Assessment history</h2><div id="phist"></div></section>' +
      '</div>';
    return {
      title: e.name, html: html,
      mount: function (root) {
        root.querySelector('#pgrowth').innerHTML = growthTopHTML(e.id);
        root.querySelector('#pchapters').innerHTML = chaptersHTML(e.id);
        root.querySelector('#pdev').innerHTML = developmentHTML(e.id);
        root.querySelector('#phist').innerHTML = historyHTML(e.id);
        var view = Store.state.viewAs;
        var a = Store.latestAssessment(e.id);
        var acts = root.querySelector('#pactions');
        if (view === 'employee') {
          acts.innerHTML = '<a class="btn btn-primary" href="#/reports">View my reports</a>';
        } else {
          acts.innerHTML = (a && a.status === 'draft' ? '<a class="btn btn-primary" href="#/assess/' + a.id + '">Continue assessment</a>' : '<button class="btn btn-primary" data-start>' + (a ? 'New assessment' : 'Start assessment') + '</button>') +
            (a && a.status === 'submitted' ? '<a class="btn btn-secondary" href="#/report/employee/' + e.id + '">Latest report</a>' : '') +
            (view === 'hr' ? '<button class="btn btn-ghost" data-edit>' + UI.icon('edit', 15) + ' Edit profile</button>' : '');
          acts.querySelector('[data-edit]') && acts.querySelector('[data-edit]').addEventListener('click', function () { Pages.people.formModal(e); });
        }
        var startBtn = root.querySelector('[data-start]');
        if (startBtn) startBtn.addEventListener('click', function () { Pages.assessments.startDraft(e.id); });
        root.querySelectorAll('[data-add]').forEach(function (b) {
          b.addEventListener('click', function () {
            var sg = Store.suggestionsFor(e.id)[parseInt(b.dataset.add, 10)];
            Pages.development.addPlan(sg);
            Router.render();
          });
        });
        root.querySelectorAll('[data-anchor]').forEach(function (ch) {
          ch.addEventListener('click', function (ev) {
            ev.preventDefault();
            var t = root.querySelector('#' + ch.dataset.anchor);
            t.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
            t.setAttribute('tabindex', '-1'); t.focus({ preventScroll: true });
          });
        });
      }
    };
  }
  return { render: render, growthPage: growthPage };
})();
