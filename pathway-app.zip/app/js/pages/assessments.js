/* Assessment queue + assessment wizard */
Pages.assessments = (function () {
  var f = { q: '', dept: '', status: '' };

  function startDraft(empId) {
    var existing = Store.state.assessments.filter(function (a) { return a.employeeId === empId && a.status === 'draft'; })[0];
    if (existing) { location.hash = '#/assess/' + existing.id; return; }
    var e = Store.emp(empId);
    var catIds = Store.state.categories.filter(function (c) {
      return Store.expectations(empId).some(function (x) { return Store.skill(x.skillId).cat === c.id; });
    }).map(function (c) { return c.id; });
    if (!catIds.length) { UI.toast('No role expectations configured for ' + e.name + '.', 'error'); return; }
    var evaluator = empId === 'EMP-1009' ? 'EMP-1015' : 'EMP-1009';
    var id = 'A-' + (2600 + Store.state.assessments.length + 1);
    while (Store.state.assessments.some(function (a) { return a.id === id; })) id = 'A-' + (parseInt(id.slice(2), 10) + 1);
    var today = new Date().toISOString().slice(0, 10);
    Store.mutate(function (s) {
      s.assessments.push({ id: id, employeeId: empId, evaluatorId: evaluator, cycle: s.cycle, status: 'draft', createdAt: today, updatedAt: today, submittedAt: null, categoryIds: catIds, items: {}, summary: '' });
      Store.addEvent('assessment', 'Assessment started for ' + e.name + ' by ' + (Store.emp(evaluator) || {}).name);
    });
    UI.toast('Draft created for ' + e.name + '.', 'success');
    location.hash = '#/assess/' + id;
  }

  function queueRow(e) {
    var a = Store.latestAssessment(e.id);
    var st = !a ? 'none' : (a.status === 'submitted' && a.cycle === Store.state.cycle ? 'done' : a.status === 'draft' ? 'draft' : 'none');
    var cov = a ? Store.coverage(a) : null;
    var action = st === 'draft' ? '<a class="btn sm btn-primary" href="#/assess/' + a.id + '">Continue</a>'
      : st === 'done' ? '<a class="btn sm btn-secondary" href="#/report/employee/' + e.id + '">View report</a>'
      : '<button class="btn sm btn-primary" data-start="' + e.id + '">Start</button>';
    return '<article class="card pad-sm personrow"><div class="grow row" style="gap:12px">' + UI.avatar(e) +
      '<div style="min-width:0;flex:1"><div class="nm" style="font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + UI.esc(e.name) + '">' + UI.esc(e.name) + '</div>' +
      '<div class="rl t-caption mut">' + UI.esc(e.dept) + ' · ' + UI.esc(Store.role(e.role).title) + '</div></div></div>' +
      '<div style="width:150px;flex:none" class="hidem">' + (cov ? UI.progress(cov.rated, cov.total, 'slim') : '<span class="t-caption mut">Not started</span>') + '</div>' +
      '<div style="flex:none">' + (st === 'done' ? UI.chipAssessStatus('submitted') : st === 'draft' ? UI.chipAssessStatus('draft') : UI.chip('Not started', 'chip-neutral', true)) + '</div>' +
      '<div style="flex:none;width:110px" class="hidem"><span class="t-caption mut">' + (a ? UI.fmtDate(a.submittedAt || a.updatedAt) : '—') + '</span></div>' +
      '<div style="flex:none">' + action + '</div></article>';
  }

  function render() {
    var html = '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Assessments</h1><p class="sec">Cycle ' + UI.esc(Store.state.cycle) + ' — every employee, with draft and submission status.</p></div></div>' +
      '<div class="filterbar" role="search"><span class="grow"><input class="input" id="aq" type="search" placeholder="Search employee…" aria-label="Search assessments"></span>' +
      '<select class="select" id="adept" aria-label="Filter by department"><option value="">All departments</option>' + Store.departments().map(function (d) { return '<option>' + UI.esc(d) + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="astatus" aria-label="Filter by status"><option value="">Any status</option><option value="done">Submitted</option><option value="draft">Draft</option><option value="none">Not started</option></select>' +
      '<span class="count" id="acount"></span></div>' +
      '<div id="alist" class="stack"></div></div>';
    return {
      title: 'Assessments', html: html,
      mount: function (root) {
        function list() {
          return Store.state.employees.filter(function (e) {
            if (f.q && e.name.toLowerCase().indexOf(f.q.toLowerCase()) === -1) return false;
            if (f.dept && e.dept !== f.dept) return false;
            if (f.status) {
              var a = Store.latestAssessment(e.id);
              var st = !a ? 'none' : (a.status === 'submitted' && a.cycle === Store.state.cycle ? 'done' : a.status === 'draft' ? 'draft' : 'none');
              if (st !== f.status) return false;
            }
            return true;
          });
        }
        function refresh() {
          var l = list();
          root.querySelector('#acount').textContent = l.length + ' of ' + Store.state.employees.length + ' employees';
          root.querySelector('#alist').innerHTML = l.length ? l.map(queueRow).join('') :
            UI.empty('cal', 'No assessments match', 'Adjust the filters to see the queue.', '<button class="btn btn-secondary sm" data-clear>Clear filters</button>');
        }
        UI.withLatency('assessments', root, function (loading) {
          if (loading) { root.querySelector('#alist').innerHTML = UI.skRows(5); return; }
          refresh();
        });
        root.querySelector('#aq').addEventListener('input', UI.debounce(function (e) { f.q = e.target.value; refresh(); }, 180));
        root.querySelector('#adept').addEventListener('change', function (e) { f.dept = e.target.value; refresh(); });
        root.querySelector('#astatus').addEventListener('change', function (e) { f.status = e.target.value; refresh(); });
        root.querySelector('#alist').addEventListener('click', function (e) {
          var st = e.target.closest('[data-start]');
          if (st) startDraft(st.dataset.start);
          if (e.target.closest('[data-clear]')) { f = { q: '', dept: '', status: '' }; Router.render(); }
        });
      }
    };
  }
  return { render: render, startDraft: startDraft };
})();

/* ---------- wizard ---------- */
Pages.wizard = (function () {
  var W = { a: null, idx: 0, saveTimer: null };

  function stations() { return W.a.categoryIds.slice(); }
  function stationSkills(k) {
    return Store.itemsList(W.a).filter(function (i) { return Store.skill(i.skillId).cat === stations()[k]; });
  }
  function saving() {
    var el = document.getElementById('wsavestate');
    if (el) el.textContent = 'Saving…';
    clearTimeout(W.saveTimer);
    W.saveTimer = setTimeout(function () {
      W.a.updatedAt = new Date().toISOString().slice(0, 10);
      Store.save();
      var el2 = document.getElementById('wsavestate');
      if (el2) el2.textContent = 'Saved ' + UI.nowTime();
    }, 800);
  }

  function railHTML() {
    var st = stations();
    var html = '<ol class="rail" aria-label="Assessment progress">';
    st.forEach(function (cid, k) {
      var skills = stationSkills(k);
      var rated = skills.filter(function (i) { return i.level; }).length;
      var done = rated === skills.length && skills.length > 0;
      html += '<li class="' + (k === W.idx ? 'cur' : done ? 'done' : '') + '"><button class="st" style="border:0;background:inherit" data-jump="' + k + '" aria-label="Go to ' + UI.esc(Store.cat(cid).name) + '">' +
        (done ? UI.icon('check', 9) : '') + '</button><button style="border:0;background:none;padding:0;font:inherit;color:inherit;cursor:pointer;flex:1;text-align:left" data-jump="' + k + '">' + UI.esc(Store.cat(cid).name) + '</button><span class="cov">' + rated + '/' + skills.length + '</span></li>';
    });
    var isReview = W.idx === st.length;
    html += '<li class="' + (isReview ? 'cur' : '') + '"><span class="st">' + (isReview ? '' : UI.icon('flag', 9)) + '</span><button style="border:0;background:none;padding:0;font:inherit;color:inherit;cursor:pointer;flex:1;text-align:left" data-jump="' + st.length + '">Review &amp; reflect</button></li>';
    return html + '</ol>';
  }
  function stepperHTML() {
    var st = stations();
    var html = '<div class="stepper" aria-hidden="true">';
    st.forEach(function (cid, k) {
      var skills = stationSkills(k);
      var done = skills.length && skills.every(function (i) { return i.level; });
      html += '<span class="st ' + (k === W.idx ? 'cur' : done ? 'done' : '') + '"></span><span class="bar ' + (k < W.idx ? 'done' : '') + '"></span>';
    });
    html += '<span class="st ' + (W.idx === st.length ? 'cur' : '') + '"></span></div>';
    var label = W.idx < st.length ? 'Category ' + (W.idx + 1) + ' of ' + st.length + ' · ' + Store.cat(st[W.idx]).name : 'Review & reflect';
    return html + '<div class="t-caption mut" style="margin-top:6px">' + UI.esc(label) + '</div>';
  }

  function skillCardHTML(i) {
    var s = Store.skill(i.skillId);
    var lv = Store.level(i.level || 0);
    return '<article class="card skillcard' + (i.level ? '' : ' unrated') + '" data-skill="' + i.skillId + '">' +
      '<div class="row wrap" style="justify-content:space-between"><h3>' + UI.esc(s.name) + '</h3>' + (i.critical ? UI.chip('Role-critical', 'chip-neutral', true) : '') + '</div>' +
      '<div class="meaning' + (i.level ? '' : ' is-empty') + '" id="m-' + i.skillId + '" aria-live="polite">' + (i.level ? '<strong>' + UI.esc(lv.label) + ' —</strong> ' + UI.esc(lv.definition) : 'Select a level to see what it means.') + '</div>' +
      '<div class="row wrap" style="margin:12px 0 4px">' + UI.dotsEdit('rate-' + i.skillId, i.level, 'Proficiency for ' + s.name) +
      '<span class="dotword" id="w-' + i.skillId + '">' + UI.levelWord(i.level) + '</span>' +
      '<span class="expectline"><span class="dots ro" aria-hidden="true"><span class="dot ghost"></span></span>Role expects: ' + UI.levelWord(i.expected) + '</span></div>' +
      '<div id="g-' + i.skillId + '" style="margin:6px 0 10px">' + (i.level ? UI.gapLine(i.level, i.expected, Store.sevOf(i.expected - i.level, i.critical)) : '') + '</div>' +
      '<div class="field"><label for="c-' + i.skillId + '">What did you observe? <span class="mut">(optional)</span></label>' +
      '<textarea class="textarea" id="c-' + i.skillId + '" maxlength="600" rows="3" placeholder="Evidence, examples, context…">' + UI.esc(i.comment) + '</textarea>' +
      '<span class="counter" id="n-' + i.skillId + '">' + (i.comment || '').length + ' / 600</span></div>' +
      '</article>';
  }

  function stationHTML() {
    var st = stations();
    if (W.idx >= st.length) return reviewHTML();
    var c = Store.cat(st[W.idx]);
    var skills = stationSkills(W.idx);
    return '<div class="row wrap" style="gap:10px;margin-bottom:4px"><h2 class="t-h2">' + UI.esc(c.name) + '</h2>' + UI.chipCat(c.id) + '</div>' +
      '<p class="sec" style="margin:0 0 16px">' + UI.esc(c.blurb) + '</p>' +
      skills.map(skillCardHTML).join('') +
      '<div class="stationbar"><button class="btn btn-ghost" data-prev' + (W.idx === 0 ? ' disabled' : '') + '>Previous</button>' +
      '<button class="btn btn-primary" data-next>Save &amp; continue</button></div>';
  }

  function reviewHTML() {
    var items = Store.itemsList(W.a);
    var cov = Store.coverage(W.a);
    var sugg = Store.suggestionsFor(W.a.employeeId);
    var rows = items.map(function (i) {
      var s = Store.skill(i.skillId);
      var gap = i.level ? i.expected - i.level : null;
      return '<tr><td>' + UI.esc(s.name) + '</td><td>' + UI.chipCat(s.cat, true) + '</td><td>' + (i.level ? UI.levelWord(i.level) : '<em class="mut">not rated</em>') + '</td><td>' + UI.levelWord(i.expected) + '</td><td>' + (gap == null ? '—' : UI.chipSev(Store.sevOf(gap, i.critical))) + '</td><td><button class="btn sm btn-ghost" data-jumpcat="' + s.cat + '">Edit</button></td></tr>';
    }).join('');
    var suggHTML = sugg.length ? '<fieldset class="dotsfield"><legend class="t-h3" style="margin-bottom:8px">Recommended development actions</legend><ul>' +
      sugg.map(function (sg, i) {
        return '<li style="padding:10px 0;border-top:1px solid var(--border)"><label style="display:flex;gap:10px;align-items:flex-start;cursor:pointer"><input type="checkbox" data-sugg="' + i + '" checked style="width:18px;height:18px;margin-top:2px;accent-color:var(--accent)">' +
          '<span><span class="t-sm" style="font-weight:600">' + UI.esc(sg.action) + '</span><span class="row wrap" style="margin-top:4px">' + UI.chipCat(sg.skillId ? Store.skill(sg.skillId).cat : 'tech', true) + UI.chip(sg.type, 'chip-accent', true) + UI.chipPriority(sg.priority) + '<span class="t-caption mut">~' + sg.weeks + ' weeks</span></span></span></label></li>';
      }).join('') + '</ul></fieldset>' : '<p class="sec">No gaps — no new recommendations needed this cycle.</p>';
    return '<h2 class="t-h2" style="margin-bottom:4px">Review &amp; reflect</h2>' +
      '<p class="sec" style="margin:0 0 16px">' + cov.rated + ' of ' + cov.total + ' skills rated. Confirm ratings, tune recommendations, then submit.</p>' +
      '<div class="reviewtable-wrap"><table class="table"><thead><tr><th scope="col">Skill</th><th scope="col">Category</th><th scope="col">Current</th><th scope="col">Expected</th><th scope="col">Gap</th><th scope="col"><span class="sr">Edit</span></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div style="margin-top:20px">' + suggHTML + '</div>' +
      '<div class="field" style="margin-top:16px"><label for="wsummary">Evaluator summary</label><textarea class="textarea" id="wsummary" rows="4" placeholder="Overall picture, progress since last cycle, agreed focus…">' + UI.esc(W.a.summary) + '</textarea></div>' +
      '<label style="display:flex;gap:10px;align-items:flex-start;margin-top:14px;cursor:pointer"><input type="checkbox" id="wattest" style="width:18px;height:18px;margin-top:2px;accent-color:var(--accent)">' +
      '<span class="t-sm sec">I confirm these ratings were discussed with the employee and evidence was considered.</span></label>' +
      '<div class="stationbar"><button class="btn btn-ghost" data-prev>Previous</button>' +
      '<span class="t-caption mut" id="wreason" style="align-self:center"></span>' +
      '<button class="btn btn-primary" id="wsubmit" disabled>Submit assessment</button></div>';
  }

  function refreshSubmit() {
    var btn = document.getElementById('wsubmit');
    if (!btn) return;
    var cov = Store.coverage(W.a);
    var attest = document.getElementById('wattest').checked;
    var reason = cov.rated < cov.total ? (cov.total - cov.rated) + ' skill' + (cov.total - cov.rated === 1 ? '' : 's') + ' left to rate' : (!attest ? 'Confirmation required' : '');
    btn.disabled = !!reason;
    document.getElementById('wreason').textContent = reason;
  }

  function paint() {
    var root = document.getElementById('main');
    root.querySelector('#wrail').innerHTML = railHTML();
    root.querySelector('#wstepper').innerHTML = stepperHTML();
    root.querySelector('#wstation').innerHTML = stationHTML();
    var cov = Store.coverage(W.a);
    root.querySelector('#wcov').textContent = cov.rated + ' of ' + cov.total + ' skills · ' + cov.pct + '%';
    var st = stations();
    root.querySelector('#wlabel').textContent = W.idx < st.length ? 'Category ' + (W.idx + 1) + ' of ' + st.length : 'Review';
    refreshSubmit();
  }

  function submit() {
    var a = W.a;
    var today = new Date().toISOString().slice(0, 10);
    var sugg = Store.suggestionsFor(a.employeeId);
    var picked = [];
    document.querySelectorAll('[data-sugg]:checked').forEach(function (c) { picked.push(sugg[parseInt(c.dataset.sugg, 10)]); });
    Store.mutate(function (s) {
      a.status = 'submitted'; a.submittedAt = today; a.updatedAt = today;
      a.summary = (document.getElementById('wsummary') || {}).value || a.summary;
      picked.forEach(function (sg) {
        var id = 'R-' + (s.recommendations.length + 1);
        while (s.recommendations.some(function (r) { return r.id === id; })) id = 'R-' + (parseInt(id.slice(2), 10) + 1);
        var due = new Date(); due.setDate(due.getDate() + sg.weeks * 7);
        s.recommendations.push({ id: id, assessmentId: a.id, employeeId: a.employeeId, skillId: sg.skillId, action: sg.action, type: sg.type, priority: sg.priority, weeks: sg.weeks, status: 'Not Started', due: due.toISOString().slice(0, 10), current: sg.current, expected: sg.expected });
      });
      Store.addEvent('assessment', 'Assessment submitted for ' + Store.emp(a.employeeId).name + ' by ' + (Store.emp(a.evaluatorId) || {}).name);
      if (picked.length) Store.addEvent('rec', 'Development plan updated for ' + Store.emp(a.employeeId).name + ' — ' + picked.length + ' recommendation' + (picked.length === 1 ? '' : 's') + ' added');
    });
    UI.toast('Assessment submitted — report is ready.', 'success', { label: 'View report', onClick: function () { location.hash = '#/report/employee/' + a.employeeId; } });
    location.hash = '#/report/employee/' + a.employeeId;
  }

  function render(params) {
    var a = Store.assessment(params.id);
    if (!a) return { title: 'Not found', html: '<div class="container">' + UI.empty('doc', 'Assessment not found', 'This assessment does not exist.', '<a class="btn btn-secondary sm" href="#/assessments">Back to queue</a>') + '</div>' };
    W.a = a;
    if (a.status === 'submitted') {
      return {
        title: 'Assessment', html: '<div class="container">' + UI.empty('check', 'This assessment is submitted', 'Submitted assessments are read-only. Open the report to view or print it.',
          '<a class="btn btn-primary sm" href="#/report/employee/' + a.employeeId + '">View report</a>') + '</div>'
      };
    }
    var st = a.categoryIds;
    W.idx = 0;
    for (var k = 0; k < st.length; k++) {
      var skills = Store.itemsList(a).filter(function (i) { return Store.skill(i.skillId).cat === st[k]; });
      if (skills.some(function (i) { return !i.level; })) { W.idx = k; break; }
      W.idx = k + 1 > st.length - 1 ? st.length : k + 1;
    }
    var e = Store.emp(a.employeeId);
    var html = '<div class="container">' +
      '<div class="momentum"><span class="who">' + UI.avatar(e, 'sm') + '<a href="#/people/' + e.id + '">' + UI.esc(e.name) + '</a></span>' +
      '<span class="t-caption" style="color:var(--accent-ink);font-weight:600" id="wlabel"></span>' +
      '<span class="t-caption mut" id="wcov"></span>' +
      '<span class="savestate" id="wsavestate" aria-live="polite">Draft</span>' +
      '<span class="actions"><button class="btn sm btn-secondary" id="wsave">Save draft</button><a class="btn sm btn-ghost" href="#/assessments">Exit</a></span></div>' +
      '<div id="wstepper" style="margin-bottom:16px"></div>' +
      '<div class="wizard"><aside class="railcol"><div id="wrail"></div></aside><section id="wstation" aria-live="polite"></section></div>' +
      '</div>';
    return {
      title: 'Assess ' + e.name, html: html,
      mount: function (root) {
        paint();
        root.querySelector('#wsave').addEventListener('click', function () {
          W.a.updatedAt = new Date().toISOString().slice(0, 10);
          Store.save();
          var el = document.getElementById('wsavestate'); if (el) el.textContent = 'Saved ' + UI.nowTime();
          UI.toast('Draft saved.', 'success');
        });

        var station = root.querySelector('#wstation');
        station.addEventListener('change', function (ev) {
          var dot = ev.target.classList.contains('sr-dot') ? ev.target : null;
          if (dot) {
            var skillId = dot.name.replace('rate-', '');
            var val = parseInt(dot.value, 10);
            W.a.items[skillId] = W.a.items[skillId] || {};
            W.a.items[skillId].level = val;
            var item = Store.itemsList(W.a).filter(function (i) { return i.skillId === skillId; })[0];
            var lv = Store.level(val);
            var m = document.getElementById('m-' + skillId);
            m.classList.remove('is-empty');
            m.innerHTML = '<strong>' + UI.esc(lv.label) + ' —</strong> ' + UI.esc(lv.definition);
            document.getElementById('w-' + skillId).textContent = lv.label;
            document.getElementById('g-' + skillId).innerHTML = UI.gapLine(val, item.expected, Store.sevOf(item.expected - val, item.critical));
            dot.closest('.skillcard').classList.remove('unrated');
            saving(); paint();
            return;
          }
          if (ev.target.id === 'wattest') refreshSubmit();
        });
        station.addEventListener('focusin', function (ev) {
          if (ev.target.classList.contains('sr-dot')) {
            var skillId = ev.target.name.replace('rate-', '');
            var lv = Store.level(parseInt(ev.target.value, 10));
            var m = document.getElementById('m-' + skillId);
            m.classList.remove('is-empty');
            m.innerHTML = '<strong>' + UI.esc(lv.label) + ' —</strong> ' + UI.esc(lv.definition);
          }
        });
        station.addEventListener('input', function (ev) {
          if (ev.target.classList.contains('textarea') && ev.target.id.indexOf('c-') === 0) {
            var skillId = ev.target.id.slice(2);
            W.a.items[skillId] = W.a.items[skillId] || {};
            W.a.items[skillId].comment = ev.target.value;
            var n = document.getElementById('n-' + skillId);
            n.textContent = ev.target.value.length + ' / 600';
            n.classList.toggle('warn', ev.target.value.length > 540);
            saving();
          }
          if (ev.target.id === 'wsummary') { W.a.summary = ev.target.value; saving(); }
        });
        station.addEventListener('click', function (ev) {
          var jump = ev.target.closest('[data-jump]');
          if (jump) { W.idx = parseInt(jump.dataset.jump, 10); paint(); window.scrollTo(0, 0); return; }
          var jc = ev.target.closest('[data-jumpcat]');
          if (jc) { W.idx = stations().indexOf(jc.dataset.jumpcat); paint(); window.scrollTo(0, 0); return; }
          if (ev.target.closest('[data-prev]')) { W.idx = Math.max(0, W.idx - 1); paint(); window.scrollTo(0, 0); return; }
          if (ev.target.closest('[data-next]')) { W.idx = Math.min(stations().length, W.idx + 1); paint(); window.scrollTo(0, 0); return; }
          if (ev.target.closest('#wsubmit')) { submit(); }
        });
        root.querySelector('#wrail').addEventListener('click', function (ev) {
          var jump = ev.target.closest('[data-jump]');
          if (jump) { W.idx = parseInt(jump.dataset.jump, 10); paint(); window.scrollTo(0, 0); }
        });
        window.addEventListener('beforeunload', function handler(ev) {
          if (document.getElementById('wsavestate') && document.getElementById('wsavestate').textContent === 'Saving…') { ev.preventDefault(); ev.returnValue = ''; }
        });
      }
    };
  }
  return { render: render };
})();
