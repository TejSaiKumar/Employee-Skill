/* Dashboard — org overview (evaluator/HR) or personal growth map (employee) */
window.Pages = window.Pages || {};

Pages.dashboard = (function () {
  function feedHTML(limit) {
    var evs = Store.state.events.slice(0, limit);
    if (!evs.length) return UI.empty('info', 'No activity yet', 'Actions like submissions and new skills will appear here.');
    return '<ul class="feed">' + evs.map(function (e) {
      var ic = e.type === 'assessment' ? 'success' : e.type === 'rec' ? 'warning' : 'info';
      var glyph = e.type === 'assessment' ? 'check' : e.type === 'rec' ? 'flag' : e.type === 'skill' ? 'plus' : 'user';
      return '<li><span class="ic ' + ic + '">' + UI.icon(glyph, 14) + '</span><span style="flex:1"><p>' + UI.esc(e.text) + '</p><span class="when">' + UI.fmtDate(e.date) + '</span></span></li>';
    }).join('') + '</ul>';
  }

  function pulseHTML() {
    var st = Store.orgStats();
    var submitted = Store.state.assessments.filter(function (a) { return a.status === 'submitted' && a.cycle === Store.state.cycle; })
      .sort(function (a, b) { return b.submittedAt.localeCompare(a.submittedAt); });
    var drafts = Store.state.assessments.filter(function (a) { return a.status === 'draft'; });
    var done = submitted.map(function (a) {
      var e = Store.emp(a.employeeId);
      return '<li><span class="ic success">' + UI.icon('check', 14) + '</span><span style="flex:1"><p><a href="#/report/employee/' + e.id + '">' + UI.esc(e.name) + '</a> — assessed by ' + UI.esc((Store.emp(a.evaluatorId) || {}).name || '—') + '</p><span class="when">' + UI.fmtDate(a.submittedAt) + '</span></span></li>';
    }).join('');
    var pend = drafts.map(function (a) {
      var e = Store.emp(a.employeeId), c = Store.coverage(a);
      return '<li><span class="ic info">' + UI.icon('cal', 14) + '</span><span style="flex:1"><p><a href="#/assess/' + a.id + '">' + UI.esc(e.name) + '</a> — draft in progress</p><span class="when">' + c.rated + ' of ' + c.total + ' skills rated</span></span></li>';
    }).join('');
    var notStarted = Store.state.employees.filter(function (e) {
      return !submitted.some(function (a) { return a.employeeId === e.id; }) && !drafts.some(function (a) { return a.employeeId === e.id; });
    }).slice(0, 3).map(function (e) {
      return '<li><span class="ic">' + UI.icon('user', 14) + '</span><span style="flex:1"><p>' + UI.esc(e.name) + ' <span class="mut t-sm">· ' + UI.esc(e.dept) + '</span></p><span class="when">Not started this cycle</span></span></li>';
    }).join('');
    return '<ul class="feed">' + (done || '<li><span class="ic">' + UI.icon('info', 14) + '</span><p class="mut">No submissions this cycle yet.</p></li>') + pend + notStarted + '</ul>' +
      '<p class="t-caption mut" style="margin-top:12px">' + st.completed + ' completed · ' + st.pending + ' pending in ' + UI.esc(Store.state.cycle) + '</p>';
  }

  function gapWatchHTML() {
    var st = Store.orgStats();
    var critical = st.gaps.filter(function (g) { return g.sev === 'critical'; });
    var rows = critical.slice(0, 5).map(function (g) {
      var e = Store.emp(g.employeeId), s = Store.skill(g.skillId);
      return '<li><span class="ic warning">' + UI.icon('alert', 14) + '</span><span style="flex:1"><p><a href="#/people/' + e.id + '">' + UI.esc(e.name) + '</a> — ' + UI.esc(s.name) + ' ' + UI.gapLine(g.current, g.expected, g.sev, false) + '</p><span class="when">' + UI.esc(UI.gapSentence(g.gap, g.sev)) + '</span></span></li>';
    }).join('');
    if (!rows) rows = '<li><span class="ic success">' + UI.icon('check', 14) + '</span><p>No critical gaps recorded. Nice work.</p></li>';
    var depts = Store.departments().map(function (d) { var s = Store.deptStats(d); return { d: d, n: s.gaps.length, c: s.critical }; })
      .sort(function (a, b) { return b.n - a.n; });
    var max = Math.max.apply(null, depts.map(function (x) { return x.n; }).concat([1]));
    var drows = depts.map(function (x) {
      return '<div class="deptgap"><span class="t-sm" style="font-weight:600">' + UI.esc(x.d) + '</span><span class="track" style="height:8px;background:var(--bg-sunken);border-radius:999px;overflow:hidden"><i style="display:block;height:100%;width:' + Math.round(x.n / max * 100) + '%;background:' + (x.c ? 'var(--warning)' : 'var(--accent)') + '"></i></span><span class="t-mono mut">' + x.n + ' gaps</span>' + (x.c ? UI.chip(x.c + ' critical', 'chip-error', true) : '<span></span>') + '</div>';
    }).join('');
    var missing = Store.mostGappedSkills(5).map(function (m) {
      var s = Store.skill(m.skillId);
      return '<li style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-top:1px solid var(--border)"><span class="t-sm" style="font-weight:600">' + UI.esc(s.name) + ' <span class="mut">· ' + UI.esc(Store.cat(s.cat).name) + '</span></span><span class="t-caption mut">' + m.n + ' employee' + (m.n > 1 ? 's' : '') + ' · worst ' + m.worst + ' lvl</span></li>';
    }).join('');
    return '<ul class="feed">' + rows + '</ul>' +
      '<h3 class="t-h3" style="margin:16px 0 6px">Department gaps</h3>' + drows +
      '<h3 class="t-h3" style="margin:16px 0 2px">Most frequently gapped skills</h3><ul>' + missing + '</ul>';
  }

  function landscapeHTML() {
    var dist = Store.proficiencyDist();
    var strong = Store.strongestSkills(5);
    var strongChips = strong.length ? strong.map(function (s) {
      return UI.chip(Store.skill(s.skillId).name + ' ×' + s.n, 'chip-success', true, 'check');
    }).join(' ') : '<span class="t-sm mut">No strengths recorded yet.</span>';
    var catAvg = Store.categoryAverages();
    var catRows = catAvg.map(function (c) {
      return '<div class="deptgap"><span>' + UI.chipCat(c.cat, true) + '</span><span class="track" style="height:8px;background:var(--bg-sunken);border-radius:999px;overflow:hidden"><i style="display:block;height:100%;width:' + (c.avg ? Math.round(c.avg / 5 * 100) : 0) + '%;background:var(--accent)"></i></span><span class="t-mono mut">' + (c.avg == null ? '—' : c.avg + ' / 5') + '</span><span class="t-caption mut">' + (c.avg == null ? 'no data' : UI.levelWord(Math.round(c.avg))) + '</span></div>';
    }).join('');
    return '<h3 class="t-h3" style="margin-bottom:10px">Proficiency distribution <span class="mut t-caption">(submitted assessments)</span></h3>' +
      UI.dist(dist.map(function (d) { return { label: d.label, n: d.n }; })) +
      '<h3 class="t-h3" style="margin:18px 0 8px">Strongest skills</h3><div class="row wrap">' + strongChips + '</div>' +
      '<h3 class="t-h3" style="margin:18px 0 6px">Average proficiency by category</h3>' + catRows;
  }

  function render() {
    if (Store.state.viewAs === 'employee') {
      return { title: 'Dashboard', html: Pages.profile.growthPage(DEMO_SELF) };
    }
    var st = Store.orgStats();
    var html =
      '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Dashboard</h1><p class="sec">Organization skill health for cycle ' + UI.esc(Store.state.cycle) + '.</p></div>' +
      '<a class="btn btn-primary" href="#/assessments">' + UI.icon('cal', 16) + ' Assessment queue</a></div>' +
      '<div class="section" id="dash-strip"></div>' +
      '<div class="section dash-hero"><article class="card"><div class="card-head"><span class="grow"><h2 class="t-h2">Assessment pulse</h2></span></div><div id="dash-pulse"></div></article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Skill landscape</h2></div><div id="dash-landscape"></div></article></div>' +
      '<div class="section dash-cols"><article class="card"><div class="card-head"><h2 class="t-h2">Gap watch</h2></div><div id="dash-gap"></div></article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Recent activity</h2></div>' + feedHTML(6) + '</article></div>' +
      '</div>';
    return {
      title: 'Dashboard', html: html,
      mount: function (root) {
        UI.withLatency('dashboard', root, function (loading) {
          if (loading) {
            root.querySelector('#dash-strip').innerHTML = '<div class="card pad-sm"><span class="sk" style="height:52px;border-radius:12px"></span></div>';
            root.querySelector('#dash-pulse').innerHTML = UI.skRows(4);
            root.querySelector('#dash-landscape').innerHTML = UI.skRows(5);
            root.querySelector('#dash-gap').innerHTML = UI.skRows(5);
            return;
          }
          root.querySelector('#dash-strip').innerHTML = UI.statStrip([
            { k: 'Total employees', v: st.employees },
            { k: 'Skills tracked', v: st.skills },
            { k: 'Assessments completed', v: st.completed },
            { k: 'Assessments pending', v: st.pending, alert: st.pending > 0 },
            { k: 'Critical skill gaps', v: st.critical, alert: st.critical > 0 },
            { k: 'Need development', v: st.needing, alert: st.needing > 0 }
          ]);
          root.querySelector('#dash-pulse').innerHTML = pulseHTML();
          root.querySelector('#dash-landscape').innerHTML = landscapeHTML();
          root.querySelector('#dash-gap').innerHTML = gapWatchHTML();
        });
      }
    };
  }
  return { render: render };
})();
