/* Settings (HR admin): proficiency model, role expectations, demo data */
Pages.settings = (function () {
  function render() {
    var html = '<div class="container settings-grid">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Settings</h1><p class="sec">Configure the proficiency framework and role expectations used across the product.</p></div></div>' +

      '<div class="acc"><button class="acc-head" aria-expanded="true" aria-controls="acc1"><span class="grow"><span class="t-h3">Proficiency model</span><span class="t-caption mut" style="display:block">Five levels, each with a plain-language definition shown wherever levels appear.</span></span><span class="chev">' + UI.icon('chev', 18) + '</span></button>' +
      '<div class="acc-body" id="acc1">' + Store.state.levels.map(function (l, i) {
        return '<div class="field" style="margin-top:14px"><label for="lv-' + l.id + '">Level ' + l.id + ' label</label>' +
          '<input class="input" id="lv-' + l.id + '" data-lvl="' + l.id + '" value="' + UI.esc(l.label) + '">' +
          '<label for="ld-' + l.id + '" style="margin-top:8px">What it means</label>' +
          '<textarea class="textarea" id="ld-' + l.id + '" data-def="' + l.id + '" rows="2">' + UI.esc(l.definition) + '</textarea></div>';
      }).join('') + '<div class="row" style="justify-content:flex-end;margin-top:16px"><button class="btn btn-primary" id="savelevels">Save changes</button></div></div></div>' +

      '<div class="acc"><button class="acc-head" aria-expanded="false" aria-controls="acc2"><span class="grow"><span class="t-h3">Role expectations</span><span class="t-caption mut" style="display:block">Expected proficiency per skill for each role — the baseline every gap is measured against.</span></span><span class="chev">' + UI.icon('chev', 18) + '</span></button>' +
      '<div class="acc-body" id="acc2" hidden><div class="field" style="margin-top:14px"><label for="role-sel">Role</label><select class="select" id="role-sel">' + Store.state.roles.map(function (r) { return '<option value="' + r.id + '">' + UI.esc(r.title) + '</option>'; }).join('') + '</select></div><div id="expect-table" style="margin-top:14px"></div></div></div>' +

      '<div class="acc"><button class="acc-head" aria-expanded="false" aria-controls="acc3"><span class="grow"><span class="t-h3">Demo data</span><span class="t-caption mut" style="display:block">Everything is stored in your browser (localStorage).</span></span><span class="chev">' + UI.icon('chev', 18) + '</span></button>' +
      '<div class="acc-body" id="acc3" hidden><p class="sec" style="margin:14px 0">Resetting restores the seeded organization: 17 employees, 28 skills, 7 assessments and 5 development plans. Your local changes will be lost.</p><button class="btn btn-destruct" id="reset2">Reset demo data</button></div></div>' +
      '</div>';
    return {
      title: 'Settings', html: html,
      mount: function (root) {
        root.querySelectorAll('.acc-head').forEach(function (h) {
          h.addEventListener('click', function () {
            var open = h.getAttribute('aria-expanded') === 'true';
            h.setAttribute('aria-expanded', open ? 'false' : 'true');
            root.querySelector('#' + h.getAttribute('aria-controls')).hidden = open;
          });
        });
        root.querySelector('#savelevels').addEventListener('click', function () {
          var ok = true;
          Store.state.levels.forEach(function (l) {
            var inp = root.querySelector('[data-lvl="' + l.id + '"]');
            if (!inp.value.trim()) { inp.closest('.field').classList.add('has-error'); ok = false; }
            else inp.closest('.field').classList.remove('has-error');
          });
          if (!ok) { UI.toast('Every level needs a label.', 'error'); return; }
          Store.mutate(function (s) {
            s.levels.forEach(function (l) {
              l.label = root.querySelector('[data-lvl="' + l.id + '"]').value.trim();
              l.definition = root.querySelector('[data-def="' + l.id + '"]').value.trim();
            });
          });
          UI.toast('Proficiency model saved.', 'success');
          Router.render();
        });

        var roleSel = root.querySelector('#role-sel');
        function paintExpect() {
          var r = Store.role(roleSel.value);
          var rows = Store.state.skills.filter(function (s) { return true; }).map(function (s) {
            var exp = r.exp[s.id];
            return '<tr><td>' + UI.chipCat(s.cat, true) + ' <span class="t-sm" style="font-weight:600">' + UI.esc(s.name) + '</span></td>' +
              '<td><label class="sr" for="ex-' + s.id + '">Expected level for ' + UI.esc(s.name) + '</label><select class="select sm" id="ex-' + s.id + '" data-skill="' + s.id + '"><option value="">Not expected</option>' +
              Store.state.levels.map(function (l) { return '<option value="' + l.id + '"' + (exp === l.id ? ' selected' : '') + '>' + l.id + ' — ' + UI.esc(l.label) + '</option>'; }).join('') + '</select></td>' +
              '<td><label class="switch" style="font-weight:500"><input type="checkbox" data-crit="' + s.id + '"' + ((r.critical || []).indexOf(s.id) > -1 ? ' checked' : '') + '><span class="track" aria-hidden="true"></span><span class="t-caption mut">critical</span></label></td></tr>';
          }).join('');
          root.querySelector('#expect-table').innerHTML = '<div class="reviewtable-wrap"><table class="table expect-table"><thead><tr><th scope="col">Skill</th><th scope="col">Expected level</th><th scope="col">Role-critical</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
            '<div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn btn-primary" id="saveexp">Save expectations</button></div>';
          root.querySelector('#saveexp').addEventListener('click', function () {
            Store.mutate(function (s) {
              var role = s.roles.filter(function (x) { return x.id === roleSel.value; })[0];
              role.exp = {}; role.critical = [];
              root.querySelectorAll('[data-skill]').forEach(function (sel) {
                if (sel.value) role.exp[sel.dataset.skill] = parseInt(sel.value, 10);
              });
              root.querySelectorAll('[data-crit]:checked').forEach(function (c) { role.critical.push(c.dataset.crit); });
            });
            UI.toast('Expectations saved for ' + Store.role(roleSel.value).title + '.', 'success');
          });
        }
        roleSel.addEventListener('change', paintExpect);
        paintExpect();

        root.querySelector('#reset2').addEventListener('click', function () {
          UI.confirmDialog({ title: 'Reset demo data?', text: 'All local changes will be replaced with the original seed data.', confirmLabel: 'Reset data', danger: true }).then(function (yes) {
            if (!yes) return;
            Store.reset(); UI.toast('Demo data reset.', 'info'); Router.render();
          });
        });
      }
    };
  }
  return { render: render };
})();
