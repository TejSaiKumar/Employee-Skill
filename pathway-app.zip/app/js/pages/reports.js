/* Reports hub + employee / department / organization reports */
Pages.reports = (function () {
  function toolbar(backHash) {
    return '<div class="toolbar no-print"><a class="btn btn-secondary sm" href="' + backHash + '">Back</a><button class="btn btn-primary sm" id="printbtn">' + UI.icon('print', 15) + ' Print / Save as PDF</button></div>';
  }
  function bindPrint(root) {
    var b = root.querySelector('#printbtn');
    if (b) b.addEventListener('click', function () { window.print(); });
  }

  function orgBlock(title) {
    return '<div class="org"><div><span class="t-eyebrow mut">Northwind Labs — People Development</span><h1 class="t-title">' + UI.esc(title) + '</h1></div>' +
      '<span class="t-mono mut">Cycle ' + UI.esc(Store.state.cycle) + '</span></div>';
  }

  /* ---------- employee ---------- */
  function employeeReport(empId) {
    var e = Store.emp(empId);
    var a = Store.latestAssessment(empId, true);
    if (!e || !a) return null;
    var items = Store.itemsList(a);
    var gaps = items.filter(function (i) { return i.level; }).map(function (i) {
      var gap = i.expected - i.level;
      return { i: i, gap: gap, sev: Store.sevOf(gap, i.critical) };
    }).filter(function (g) { return g.gap >= 1; }).sort(function (x, y) { return y.gap - x.gap; });
    var recs = Store.recsFor(empId).filter(function (r) { return r.assessmentId === a.id || !r.assessmentId; });
    var catTables = Store.state.categories.map(function (c) {
      var rows = items.filter(function (i) { return Store.skill(i.skillId).cat === c.id; });
      if (!rows.length) return '';
      return '<section><h2>' + UI.esc(c.name) + '</h2><table class="table"><thead><tr><th scope="col">Skill</th><th scope="col">Current</th><th scope="col">Expected</th><th scope="col">Gap</th></tr></thead><tbody>' +
        rows.map(function (i) {
          var gap = i.level ? i.expected - i.level : null;
          return '<tr><td>' + UI.esc(Store.skill(i.skillId).name) + '</td><td>' + (i.level ? UI.dotsRead(i.level) + ' ' + UI.levelWord(i.level) : 'Not rated') + '</td><td>' + UI.levelWord(i.expected) + '</td><td>' + (gap == null ? '—' : UI.esc(UI.gapSentence(gap, Store.sevOf(gap, i.critical)))) + '</td></tr>';
        }).join('') + '</tbody></table></section>';
    }).join('');
    var comments = items.filter(function (i) { return i.comment; }).map(function (i) {
      return '<p class="quote" style="margin:0 0 10px"><strong>' + UI.esc(Store.skill(i.skillId).name) + ':</strong> ' + UI.esc(i.comment) + '</p>';
    }).join('');
    var html = toolbar('#/people/' + empId) + '<article class="report">' + orgBlock('Employee Skill Report — ' + e.name) +
      '<dl class="metagrid"><div><dt>Employee ID</dt><dd class="t-mono">' + UI.esc(e.id) + '</dd></div><div><dt>Department</dt><dd>' + UI.esc(e.dept) + '</dd></div><div><dt>Designation</dt><dd>' + UI.esc(Store.role(e.role).title) + '</dd></div><div><dt>Manager</dt><dd>' + UI.esc(Store.managerName(e)) + '</dd></div><div><dt>Evaluator</dt><dd>' + UI.esc((Store.emp(a.evaluatorId) || {}).name || '—') + '</dd></div><div><dt>Assessment date</dt><dd>' + UI.fmtDate(a.submittedAt) + '</dd></div></dl>' +
      '<section><h2>Competency profile</h2>' + UI.wheel(UI.catAveragesFor(empId, true), 220) + '</section>' +
      catTables +
      '<section><h2>Overall summary</h2><p class="quote">' + UI.esc(a.summary || 'No summary was recorded for this assessment.') + '</p></section>' +
      '<section><h2>Skill gaps</h2>' + (gaps.length ? '<ul>' + gaps.map(function (g) {
        return '<li style="padding:8px 0;border-top:1px solid var(--border)"><div class="row wrap" style="justify-content:space-between"><span class="t-sm" style="font-weight:600">' + UI.esc(Store.skill(g.i.skillId).name) + '</span>' + UI.chipSev(g.sev) + '</div>' + UI.gapLine(g.i.level, g.i.expected, g.sev) + '</li>';
      }).join('') + '</ul>' : '<p class="sec">No gaps: all assessed skills meet or exceed role expectations.</p>') + '</section>' +
      '<section><h2>Recommendations</h2>' + (recs.length ? '<ol style="list-style:decimal;padding-left:20px;display:flex;flex-direction:column;gap:8px">' + recs.map(function (r) {
        return '<li><span class="t-sm" style="font-weight:600">' + UI.esc(r.action) + '</span> <span class="t-caption mut">· ' + UI.esc(r.type) + ' · ' + UI.esc(r.priority) + ' priority · ' + r.weeks + ' wks · due ' + UI.fmtDate(r.due) + ' · ' + UI.esc(r.status) + '</span></li>';
      }).join('') + '</ol>' : '<p class="sec">No recommendations recorded.</p>') + '</section>' +
      (comments ? '<section><h2>Evaluator comments</h2>' + comments + '</section>' : '') +
      '<div class="foot"><span>Generated ' + UI.fmtDate(new Date().toISOString().slice(0, 10)) + ' · Pathway</span><span>' + UI.esc(a.id) + '</span></div>' +
      '</article>';
    return html;
  }

  /* ---------- department ---------- */
  function deptReport(dept) {
    var st = Store.deptStats(dept);
    var emps = Store.state.employees.filter(function (e) { return e.dept === dept; });
    var catAvg = Store.categoryAverages(dept);
    var strong = [];
    emps.forEach(function (e) {
      Store.gapsFor(e.id).gaps.forEach(function (g) { if (g.gap <= 0 && g.current >= 4) strong.push(g); });
    });
    var priorities = [];
    emps.forEach(function (e) { priorities = priorities.concat(Store.suggestionsFor(e.id)); });
    priorities.sort(function (a, b) { return b.gap - a.gap; });
    var html = toolbar('#/reports') + '<article class="report">' + orgBlock('Department Skill Report — ' + dept) +
      '<dl class="metagrid"><div><dt>Employees</dt><dd>' + emps.length + '</dd></div><div><dt>Assessed this cycle</dt><dd>' + st.assessed + ' of ' + emps.length + '</dd></div><div><dt>Open gaps</dt><dd>' + st.gaps.length + ' (' + st.critical + ' critical)</dd></div></dl>' +
      '<section><h2>Average proficiency by category</h2>' + UI.dist(catAvg.map(function (c) { return { label: c.name, n: c.avg == null ? 0 : c.avg }; })) + '<p class="t-caption mut" style="margin-top:6px">Scale 0–5 · categories without data show 0.</p></section>' +
      '<section><h2>Employees</h2><table class="table"><thead><tr><th scope="col">Employee</th><th scope="col">Role</th><th scope="col">Overall</th><th scope="col">Open gaps</th><th scope="col">Status</th></tr></thead><tbody>' +
      emps.map(function (e) {
        var a = Store.latestAssessment(e.id, true);
        var vals = a ? Object.keys(a.items).map(function (k) { return a.items[k].level; }).filter(Boolean) : [];
        var avg = vals.length ? Math.round(vals.reduce(function (x, y) { return x + y; }, 0) / vals.length * 10) / 10 : null;
        var og = Store.openGaps(e.id).length;
        return '<tr><td>' + UI.esc(e.name) + '</td><td>' + UI.esc(Store.role(e.role).title) + '</td><td class="num">' + (avg == null ? '—' : avg + ' / 5') + '</td><td class="num">' + og + '</td><td>' + (a ? UI.chipAssessStatus(a.status) : UI.chip('Not started', 'chip-neutral', true)) + '</td></tr>';
      }).join('') + '</tbody></table></section>' +
      '<section><h2>Skill gaps</h2>' + (st.gaps.length ? '<ul>' + st.gaps.sort(function (a, b) { return b.gap - a.gap; }).slice(0, 10).map(function (g) {
        return '<li style="padding:8px 0;border-top:1px solid var(--border)"><span class="t-sm" style="font-weight:600">' + UI.esc(Store.emp(g.employeeId).name) + ' — ' + UI.esc(Store.skill(g.skillId).name) + '</span> ' + UI.gapLine(g.current, g.expected, g.sev) + '</li>';
      }).join('') + '</ul>' : '<p class="sec">No open gaps in this department.</p>') + '</section>' +
      '<section><h2>Strongest skills</h2>' + (strong.length ? '<div class="row wrap">' + strong.slice(0, 8).map(function (g) { return UI.chip(Store.skill(g.skillId).name + ' · ' + UI.levelWord(g.current), 'chip-success', true, 'check'); }).join(' ') + '</div>' : '<p class="sec">No advanced strengths recorded yet.</p>') + '</section>' +
      '<section><h2>Development priorities</h2>' + (priorities.length ? '<ol style="list-style:decimal;padding-left:20px;display:flex;flex-direction:column;gap:8px">' + priorities.slice(0, 6).map(function (p) {
        return '<li><span class="t-sm" style="font-weight:600">' + UI.esc(p.action) + '</span> <span class="t-caption mut">· ' + UI.esc(Store.emp(p.employeeId).name) + ' · gap ' + p.gap + ' lvl</span></li>';
      }).join('') + '</ol>' : '<p class="sec">No pending priorities.</p>') + '</section>' +
      '<div class="foot"><span>Generated ' + UI.fmtDate(new Date().toISOString().slice(0, 10)) + ' · Pathway</span><span>' + UI.esc(dept) + '</span></div></article>';
    return html;
  }

  /* ---------- organization ---------- */
  function orgReport() {
    var st = Store.orgStats();
    var recs = Store.state.recommendations;
    var done = recs.filter(function (r) { return r.status === 'Completed'; }).length;
    var html = toolbar('#/reports') + '<article class="report">' + orgBlock('Organization Skill Report') +
      '<dl class="metagrid"><div><dt>Employees</dt><dd>' + st.employees + '</dd></div><div><dt>Assessments completed</dt><dd>' + st.completed + '</dd></div><div><dt>Assessments pending</dt><dd>' + st.pending + '</dd></div><div><dt>Critical gaps</dt><dd>' + st.critical + '</dd></div><div><dt>Employees needing development</dt><dd>' + st.needing + '</dd></div><div><dt>Skills tracked</dt><dd>' + st.skills + '</dd></div></dl>' +
      '<section><h2>Assessment completion</h2><div class="progress" style="max-width:420px"><i style="width:' + Math.round(st.completed / st.employees * 100) + '%"></i></div><p class="t-caption mut" style="margin-top:6px">' + st.completed + ' of ' + st.employees + ' employees assessed in ' + UI.esc(Store.state.cycle) + '</p></section>' +
      '<section><h2>Proficiency distribution</h2>' + UI.dist(Store.proficiencyDist().map(function (d) { return { label: d.label, n: d.n }; })) + '</section>' +
      '<section><h2>Average proficiency by category</h2>' + UI.dist(Store.categoryAverages().map(function (c) { return { label: c.name, n: c.avg == null ? 0 : c.avg }; })) + '</section>' +
      '<section><h2>Critical gaps</h2>' + (st.gaps.filter(function (g) { return g.sev === 'critical'; }).length ? '<ul>' + st.gaps.filter(function (g) { return g.sev === 'critical'; }).map(function (g) {
        return '<li style="padding:8px 0;border-top:1px solid var(--border)"><span class="t-sm" style="font-weight:600">' + UI.esc(Store.emp(g.employeeId).name) + ' — ' + UI.esc(Store.skill(g.skillId).name) + '</span> ' + UI.gapLine(g.current, g.expected, g.sev) + '</li>';
      }).join('') + '</ul>' : '<p class="sec">No critical gaps organization-wide.</p>') + '</section>' +
      '<section><h2>Development progress</h2><p class="t-sm sec" style="margin:0 0 8px">' + done + ' of ' + recs.length + ' recommendations completed · ' + recs.filter(function (r) { return r.status === 'In Progress'; }).length + ' in progress.</p>' +
      '<div class="progress success" style="max-width:420px"><i style="width:' + (recs.length ? Math.round(done / recs.length * 100) : 0) + '%"></i></div></section>' +
      '<section><h2>Most frequently gapped skills</h2><ul>' + Store.mostGappedSkills(6).map(function (m) {
        return '<li style="padding:8px 0;border-top:1px solid var(--border)"><span class="t-sm" style="font-weight:600">' + UI.esc(Store.skill(m.skillId).name) + '</span> <span class="t-caption mut">· ' + m.n + ' employee' + (m.n === 1 ? '' : 's') + ' · worst ' + m.worst + ' levels</span></li>';
      }).join('') + '</ul></section>' +
      '<div class="foot"><span>Generated ' + UI.fmtDate(new Date().toISOString().slice(0, 10)) + ' · Pathway</span><span>org</span></div></article>';
    return html;
  }

  function hub() {
    var submitted = Store.state.assessments.filter(function (a) { return a.status === 'submitted'; }).sort(function (a, b) { return b.submittedAt.localeCompare(a.submittedAt); });
    var html = '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Reports</h1><p class="sec">Print-ready reports for employees, departments and the organization.</p></div></div>' +
      '<div class="section reporthub">' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Employee</h2></div><p class="sec t-sm" style="margin:0 0 12px">Full skill record, gaps, recommendations and evaluator comments.</p>' +
      '<div class="field"><label for="r-emp">Employee</label><select class="select" id="r-emp">' + Store.state.employees.filter(function (e) { return Store.latestAssessment(e.id, true); }).map(function (e) { return '<option value="' + e.id + '">' + UI.esc(e.name) + '</option>'; }).join('') + '</select></div>' +
      '<button class="btn btn-primary" style="margin-top:12px" data-view="employee">View report</button></article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Department</h2></div><p class="sec t-sm" style="margin:0 0 12px">Headcount, proficiency mix, gaps, strengths and priorities.</p>' +
      '<div class="field"><label for="r-dept">Department</label><select class="select" id="r-dept">' + Store.departments().map(function (d) { return '<option>' + UI.esc(d) + '</option>'; }).join('') + '</select></div>' +
      '<button class="btn btn-primary" style="margin-top:12px" data-view="department">View report</button></article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Organization</h2></div><p class="sec t-sm" style="margin:0 0 12px">Completion, distribution, critical gaps and development progress.</p>' +
      '<button class="btn btn-primary" data-view="org" style="margin-top:26px">View report</button></article>' +
      '</div>' +
      '<section class="section"><h2 class="t-h2" style="margin-bottom:12px">Recently submitted</h2><article class="card pad-sm">' +
      (submitted.length ? submitted.map(function (a) {
        var e = Store.emp(a.employeeId);
        return '<div class="gaprow" style="grid-template-columns:auto 1fr auto auto">' + UI.avatar(e, 'sm') + '<span class="t-sm" style="font-weight:600">' + UI.esc(e.name) + ' <span class="mut t-caption">· ' + UI.esc(e.dept) + '</span></span><span class="t-caption mut">' + UI.fmtDate(a.submittedAt) + ' · ' + UI.esc((Store.emp(a.evaluatorId) || {}).name || '—') + '</span><a class="btn sm btn-secondary" href="#/report/employee/' + e.id + '">Open</a></div>';
      }).join('') : UI.empty('doc', 'No submitted assessments yet', 'Reports become available once an assessment is submitted.')) +
      '</article></section></div>';
    return {
      title: 'Reports', html: html,
      mount: function (root) {
        var empSel = root.querySelector('#r-emp');
        if (!empSel.options.length) {
          empSel.closest('.field').innerHTML = '<p class="t-sm sec">No submitted assessments yet — employee reports unlock after the first submission.</p>';
          root.querySelector('[data-view="employee"]').disabled = true;
        }
        root.querySelectorAll('[data-view]').forEach(function (b) {
          b.addEventListener('click', function () {
            var t = b.dataset.view;
            if (t === 'employee') location.hash = '#/report/employee/' + root.querySelector('#r-emp').value;
            if (t === 'department') location.hash = '#/report/department/' + encodeURIComponent(root.querySelector('#r-dept').value);
            if (t === 'org') location.hash = '#/report/org/all';
          });
        });
      }
    };
  }

  function renderHub() { return hub(); }
  function renderView(params) {
    var html = null;
    if (params.type === 'employee') html = employeeReport(params.key);
    if (params.type === 'department') html = deptReport(decodeURIComponent(params.key));
    if (params.type === 'org') html = orgReport();
    if (!html) return { title: 'Report', html: '<div class="container">' + UI.empty('doc', 'Report unavailable', 'No submitted assessment exists for this subject yet.', '<a class="btn btn-secondary sm" href="#/reports">Back to reports</a>') + '</div>' };
    return {
      title: 'Report', html: '<div class="container">' + html + '</div>',
      mount: function (root) { bindPrint(root); }
    };
  }
  return { render: renderHub, renderView: renderView };
})();
Pages.report = { render: function (p) { return Pages.reports.renderView(p); } };
