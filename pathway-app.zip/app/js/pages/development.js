/* Development recommendations & plans */
Pages.development = (function () {
  var f = { q: '', dept: '', status: '', priority: '' };

  function addPlan(sg) {
    var today = new Date();
    var due = new Date(); due.setDate(due.getDate() + sg.weeks * 7);
    Store.mutate(function (s) {
      var id = 'R-' + (s.recommendations.length + 1);
      while (s.recommendations.some(function (r) { return r.id === id; })) id = 'R-' + (parseInt(id.slice(2), 10) + 1);
      s.recommendations.push({
        id: id, assessmentId: null, employeeId: sg.employeeId, skillId: sg.skillId, action: sg.action,
        type: sg.type, priority: sg.priority, weeks: sg.weeks, status: 'Not Started',
        due: due.toISOString().slice(0, 10), current: sg.current, expected: sg.expected
      });
      Store.addEvent('rec', 'Development recommendation created for ' + Store.emp(sg.employeeId).name + ' — ' + sg.action);
    });
    UI.toast('Added to development plan.', 'success');
  }

  function recs() {
    var view = Store.state.viewAs;
    return Store.state.recommendations.filter(function (r) {
      var e = Store.emp(r.employeeId);
      if (!e) return false;
      if (view === 'employee' && r.employeeId !== DEMO_SELF) return false;
      if (f.status && r.status !== f.status) return false;
      if (f.priority && r.priority !== f.priority) return false;
      if (f.dept && e.dept !== f.dept) return false;
      if (f.q && (e.name + ' ' + r.action + ' ' + Store.skill(r.skillId).name).toLowerCase().indexOf(f.q.toLowerCase()) === -1) return false;
      return true;
    }).sort(function (a, b) {
      var w = { High: 0, Medium: 1, Low: 2 };
      var s = { 'In Progress': 0, 'Not Started': 1, Completed: 2 };
      return s[a.status] - s[b.status] || w[a.priority] - w[b.priority];
    });
  }

  function render() {
    var all = Store.state.recommendations;
    var done = all.filter(function (r) { return r.status === 'Completed'; }).length;
    var inprog = all.filter(function (r) { return r.status === 'In Progress'; }).length;
    var view = Store.state.viewAs;
    var html = '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Development</h1><p class="sec">' + (view === 'employee' ? 'Your' : 'Organization-wide') + ' development plans, generated from assessment gaps and tracked to completion.</p></div></div>' +
      '<div class="section card pad-sm"><div class="row wrap" style="gap:24px;align-items:center">' +
      '<div style="flex:1;min-width:200px"><div class="row spread" style="margin-bottom:6px"><span class="t-sm" style="font-weight:600">Plan completion</span><span class="t-caption mut">' + done + ' of ' + all.length + ' completed</span></div>' +
      '<div class="progress success"><i style="width:' + (all.length ? Math.round(done / all.length * 100) : 0) + '%"></i></div></div>' +
      '<div class="row wrap">' + UI.chip(inprog + ' in progress', 'chip-info', true) + UI.chip((all.length - done - inprog) + ' not started', 'chip-neutral', true) + UI.chip(done + ' completed', 'chip-success', true) + '</div>' +
      '</div></div>' +
      '<div class="filterbar" role="search"><span class="grow"><input class="input" id="dq" type="search" placeholder="Search employee, skill or action…" aria-label="Search recommendations"></span>' +
      (view !== 'employee' ? '<select class="select" id="ddept" aria-label="Filter by department"><option value="">All departments</option>' + Store.departments().map(function (d) { return '<option>' + UI.esc(d) + '</option>'; }).join('') + '</select>' : '') +
      '<select class="select" id="dstatus" aria-label="Filter by status"><option value="">Any status</option><option>Not Started</option><option>In Progress</option><option>Completed</option></select>' +
      '<select class="select" id="dprio" aria-label="Filter by priority"><option value="">Any priority</option><option>High</option><option>Medium</option><option>Low</option></select>' +
      '<span class="count" id="dcount"></span></div>' +
      '<div class="section"><article class="card pad-sm"><div id="dlist"></div></article></div>' +
      (view !== 'employee' ? '<section class="section"><h2 class="t-h2" style="margin-bottom:12px">Suggested from open gaps</h2><article class="card pad-sm"><div id="dsugg"></div></article></section>' : '') +
      '</div>';
    return {
      title: 'Development', html: html,
      mount: function (root) {
        function row(r, withCtl) {
          var e = Store.emp(r.employeeId), s = Store.skill(r.skillId);
          return '<div class="recrow"><div><div class="t-sm" style="font-weight:600">' + UI.esc(r.action) + '</div>' +
            '<div class="meta" style="margin-top:6px">' +
            (view !== 'employee' ? '<a class="chip chip-neutral sm" href="#/people/' + e.id + '">' + UI.esc(e.name) + '</a>' : '') +
            UI.chipCat(s.cat, true) + '<span class="t-caption mut">' + UI.esc(s.name) + ' · ' + UI.levelWord(r.current) + ' → ' + UI.levelWord(r.expected) + '</span>' +
            UI.chip(r.type, 'chip-accent', true) + UI.chipPriority(r.priority) +
            '<span class="t-caption mut">' + r.weeks + ' wks · due ' + UI.fmtDate(r.due) + '</span></div></div>' +
            '<div class="ctl">' + (withCtl ?
              '<label class="sr" for="st-' + r.id + '">Status for ' + UI.esc(r.action) + '</label><select class="select sm" id="st-' + r.id + '" data-rec="' + r.id + '"><option' + (r.status === 'Not Started' ? ' selected' : '') + '>Not Started</option><option' + (r.status === 'In Progress' ? ' selected' : '') + '>In Progress</option><option' + (r.status === 'Completed' ? ' selected' : '') + '>Completed</option></select>'
              : UI.chipRecStatus(r.status)) + '</div></div>';
        }
        function refresh() {
          var list = recs();
          root.querySelector('#dcount').textContent = list.length + ' plan' + (list.length === 1 ? '' : 's');
          root.querySelector('#dlist').innerHTML = list.length ? list.map(function (r) { return row(r, true); }).join('') :
            UI.empty('flag', 'No development plans match', 'Adjust filters, or add suggested actions from open gaps below.');
          var sg = root.querySelector('#dsugg');
          if (sg) {
            var suggs = [];
            Store.state.employees.forEach(function (e) { suggs = suggs.concat(Store.suggestionsFor(e.id)); });
            suggs.sort(function (a, b) { return b.gap - a.gap; });
            sg.innerHTML = suggs.length ? suggs.slice(0, 8).map(function (x, i) {
              var e = Store.emp(x.employeeId), s = Store.skill(x.skillId);
              return '<div class="recrow"><div><div class="t-sm" style="font-weight:600">' + UI.esc(x.action) + '</div>' +
                '<div class="meta" style="margin-top:6px"><a class="chip chip-neutral sm" href="#/people/' + e.id + '">' + UI.esc(e.name) + '</a>' + UI.chipCat(s.cat, true) +
                '<span class="t-caption mut">gap ' + x.gap + ' lvl · ~' + x.weeks + ' wks</span>' + UI.chipPriority(x.priority) + '</div></div>' +
                '<div class="ctl"><button class="btn sm btn-secondary" data-add="' + i + '">' + UI.icon('plus', 14) + ' Add to plan</button></div></div>';
            }).join('') : UI.empty('check', 'Nothing suggested', 'Every open gap already has an active plan.');
            sg.querySelectorAll('[data-add]').forEach(function (b) {
              b.addEventListener('click', function () {
                var idx = parseInt(b.dataset.add, 10);
                var all2 = [];
                Store.state.employees.forEach(function (e) { all2 = all2.concat(Store.suggestionsFor(e.id)); });
                all2.sort(function (a, c) { return c.gap - a.gap; });
                addPlan(all2[idx]);
                Router.render();
              });
            });
          }
        }
        UI.withLatency('development', root, function (loading) {
          if (loading) { root.querySelector('#dlist').innerHTML = UI.skRows(4); return; }
          refresh();
        });
        root.querySelector('#dq').addEventListener('input', UI.debounce(function (e) { f.q = e.target.value; refresh(); }, 180));
        ['ddept', 'dstatus', 'dprio'].forEach(function (id) {
          var el = root.querySelector('#' + id);
          if (el) el.addEventListener('change', function (e) {
            if (id === 'ddept') f.dept = e.target.value;
            if (id === 'dstatus') f.status = e.target.value;
            if (id === 'dprio') f.priority = e.target.value;
            refresh();
          });
        });
        root.querySelector('#dlist').addEventListener('change', function (e) {
          var sel = e.target.closest('[data-rec]');
          if (!sel) return;
          var r = Store.state.recommendations.filter(function (x) { return x.id === sel.dataset.rec; })[0];
          Store.mutate(function () { r.status = sel.value; });
          UI.toast('Status updated to “' + sel.value + '”.', 'success');
          refresh();
        });
      }
    };
  }
  return { render: render, addPlan: addPlan };
})();
