/* Skills library — categorized CRUD */
Pages.skills = (function () {
  var f = { q: '', cat: '' };

  function rowHTML(s) {
    var use = Store.skillUsage(s.id);
    var canEdit = Store.state.viewAs === 'hr';
    return '<div class="skillrow"><div><div class="nm" title="' + UI.esc(s.name) + '">' + UI.esc(s.name) + '</div>' +
      '<span class="t-caption mut">Expected in ' + use.inRoles + ' role' + (use.inRoles === 1 ? '' : 's') + ' · rated ' + use.rated + ' time' + (use.rated === 1 ? '' : 's') + '</span></div>' +
      '<div class="meta">' +
      (canEdit ? '<button class="iconbtn sm" data-edit="' + s.id + '" aria-label="Edit ' + UI.esc(s.name) + '">' + UI.icon('edit', 15) + '</button>' +
        '<button class="iconbtn sm" data-del="' + s.id + '" aria-label="Delete ' + UI.esc(s.name) + '">' + UI.icon('trash', 15) + '</button>' : '') +
      '</div></div>';
  }

  function listHTML() {
    var q = f.q.toLowerCase();
    var any = false;
    var html = Store.state.categories.map(function (c) {
      if (f.cat && f.cat !== c.id) return '';
      var skills = Store.state.skills.filter(function (s) { return s.cat === c.id && (!q || s.name.toLowerCase().indexOf(q) > -1); });
      if (!skills.length) return '';
      any = true;
      return '<article class="card chapter"><div class="card-head">' + UI.chipCat(c.id) +
        '<span class="grow"><h3 class="t-h3">' + UI.esc(c.name) + '</h3><p class="t-caption mut">' + UI.esc(c.blurb) + '</p></span>' +
        '<span class="t-caption mut">' + skills.length + ' skill' + (skills.length === 1 ? '' : 's') + '</span></div>' +
        skills.map(rowHTML).join('') + '</article>';
    }).join('');
    if (!any) return UI.empty('search', 'No skills match', 'Try another search term, or add the skill to the library.', '<button class="btn btn-secondary sm" data-clear>Clear search</button>');
    return html;
  }

  function formModal(existing, presetCat) {
    var body =
      '<div class="field"><label for="sf-name">Skill name <span class="mut">(required)</span></label><input class="input" id="sf-name" value="' + UI.esc(existing ? existing.name : '') + '" autocomplete="off"><span class="error-msg" hidden></span></div>' +
      '<div class="field"><label for="sf-cat">Category <span class="mut">(required)</span></label><select class="select" id="sf-cat">' + Store.state.categories.map(function (c) { return '<option value="' + c.id + '"' + ((existing ? existing.cat : presetCat) === c.id ? ' selected' : '') + '>' + UI.esc(c.name) + '</option>'; }).join('') + '</select></div>' +
      '<p class="t-caption mut">Each skill uses the shared 5-level proficiency framework: ' + Store.state.levels.map(function (l) { return l.label; }).join(' · ') + '.</p>';
    UI.openModal({
      title: existing ? 'Edit skill' : 'Add skill',
      body: body,
      footer: '<button class="btn btn-ghost" data-cancel>Cancel</button><button class="btn btn-primary" data-save>' + (existing ? 'Save changes' : 'Add skill') + '</button>',
      onMount: function (panel, close) {
        panel.querySelector('[data-cancel]').addEventListener('click', close);
        panel.querySelector('[data-save]').addEventListener('click', function () {
          var name = panel.querySelector('#sf-name'), cat = panel.querySelector('#sf-cat');
          var val = name.value.trim();
          var span = panel.querySelector('.error-msg');
          var dup = Store.state.skills.some(function (s) { return s.cat === cat.value && s.name.toLowerCase() === val.toLowerCase() && (!existing || s.id !== existing.id); });
          var msg = !val ? 'Skill name is required.' : dup ? 'A skill with this name already exists in this category.' : '';
          name.closest('.field').classList.toggle('has-error', !!msg);
          span.hidden = !msg; span.textContent = msg;
          if (msg) return;
          Store.mutate(function (s) {
            if (existing) { existing.name = val; existing.cat = cat.value; }
            else {
              var id = 'x' + (s.skills.length + 1);
              while (s.skills.some(function (k) { return k.id === id; })) id = 'x' + (parseInt(id.slice(1), 10) + 1);
              s.skills.push({ id: id, cat: cat.value, name: val });
              Store.addEvent('skill', 'Skill “' + val + '” added to ' + Store.cat(cat.value).name);
            }
          });
          close(); UI.toast(existing ? 'Skill saved.' : 'Skill added to the library.', 'success'); Router.render();
        });
      }
    });
  }

  function render(params) {
    if (params && params.q) f.q = params.q;
    var canEdit = Store.state.viewAs === 'hr';
    var html = '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Skills</h1><p class="sec">The shared skill library, organized in six competency categories.</p></div>' +
      (canEdit ? '<button class="btn btn-primary" id="addskill">' + UI.icon('plus', 16) + ' Add skill</button>' : '') + '</div>' +
      '<div class="filterbar" role="search"><span class="grow"><input class="input" id="sq" type="search" placeholder="Search skills…" aria-label="Search skills"></span>' +
      '<select class="select" id="scat" aria-label="Filter by category"><option value="">All categories</option>' + Store.state.categories.map(function (c) { return '<option value="' + c.id + '">' + UI.esc(c.name) + '</option>'; }).join('') + '</select>' +
      '<span class="count">' + Store.state.skills.length + ' skills</span></div>' +
      '<div id="slist" class="stack"></div></div>';
    return {
      title: 'Skills', html: html,
      mount: function (root) {
        function refresh() { root.querySelector('#slist').innerHTML = listHTML(); }
        root.querySelector('#sq').value = f.q;
        refresh();
        root.querySelector('#sq').addEventListener('input', UI.debounce(function (e) { f.q = e.target.value; refresh(); }, 180));
        root.querySelector('#scat').addEventListener('change', function (e) { f.cat = e.target.value; refresh(); });
        var addBtn = root.querySelector('#addskill');
        if (addBtn) addBtn.addEventListener('click', function () { formModal(null, f.cat || 'tech'); });
        root.querySelector('#slist').addEventListener('click', function (e) {
          if (e.target.closest('[data-clear]')) { f.q = ''; root.querySelector('#sq').value = ''; refresh(); return; }
          var ed = e.target.closest('[data-edit]');
          if (ed) { formModal(Store.skill(ed.dataset.edit)); return; }
          var del = e.target.closest('[data-del]');
          if (del) {
            var s = Store.skill(del.dataset.del);
            var use = Store.skillUsage(s.id);
            UI.confirmDialog({
              title: 'Delete “' + s.name + '”?',
              text: use.rated ? 'This skill appears in ' + use.rated + ' assessment record' + (use.rated === 1 ? '' : 's') + '. Historic records keep their ratings, but the skill leaves the library and role expectations.' : 'This skill will be removed from the library and role expectations.',
              confirmLabel: 'Delete skill', danger: true
            }).then(function (yes) {
              if (!yes) return;
              Store.mutate(function (st) {
                st.skills = st.skills.filter(function (k) { return k.id !== s.id; });
                st.roles.forEach(function (r) { delete r.exp[s.id]; r.critical = (r.critical || []).filter(function (c) { return c !== s.id; }); });
                Store.addEvent('skill', 'Skill “' + s.name + '” removed from the library');
              });
              UI.toast('Skill deleted.', 'info'); Router.render();
            });
          }
        });
      }
    };
  }
  return { render: render };
})();
