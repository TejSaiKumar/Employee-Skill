/* Skill gap analysis */
Pages.gaps = (function () {
  var f = { q: '', dept: '', sev: 'open', role: '' };
  var SEVS = ['critical', 'required', 'monitor', 'meet', 'exceeds'];

  function allGaps() {
    var out = [];
    Store.state.employees.forEach(function (e) {
      Store.gapsFor(e.id).gaps.forEach(function (g) { out.push(g); });
    });
    return out;
  }
  function filtered() {
    return allGaps().filter(function (g) {
      var e = Store.emp(g.employeeId), s = Store.skill(g.skillId);
      if (f.sev === 'open' && g.gap < 1) return false;
      if (f.sev !== 'open' && f.sev !== 'all' && g.sev !== f.sev) return false;
      if (f.dept && e.dept !== f.dept) return false;
      if (f.role && e.role !== f.role) return false;
      if (f.q && (e.name + ' ' + s.name).toLowerCase().indexOf(f.q.toLowerCase()) === -1) return false;
      return true;
    }).sort(function (a, b) {
      return SEVS.indexOf(a.sev) - SEVS.indexOf(b.sev) || b.gap - a.gap || Store.emp(a.employeeId).name.localeCompare(Store.emp(b.employeeId).name);
    });
  }

  function render() {
    var assessed = Store.state.employees.filter(function (e) { return Store.latestAssessment(e.id); }).length;
    var html = '<div class="container">' +
      '<div class="pagehead"><div class="grow"><h1 class="t-display">Skill gaps</h1>' +
      '<p class="sec">Required level − current level, from each employee’s latest assessment · ' + assessed + ' of ' + Store.state.employees.length + ' employees assessed.</p></div></div>' +
      '<div class="filterbar" role="search"><span class="grow"><input class="input" id="gq" type="search" placeholder="Search employee or skill…" aria-label="Search gaps"></span>' +
      '<select class="select" id="gdept" aria-label="Filter by department"><option value="">All departments</option>' + Store.departments().map(function (d) { return '<option>' + UI.esc(d) + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="grole" aria-label="Filter by role"><option value="">All roles</option>' + Store.state.roles.map(function (r) { return '<option value="' + r.id + '">' + UI.esc(r.title) + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="gsev" aria-label="Filter by severity"><option value="open">Open gaps only</option><option value="critical">Critical only</option><option value="required">Development required</option><option value="monitor">Monitor (1 level)</option><option value="meet">Meets / exceeds</option><option value="all">Everything</option></select>' +
      '<span class="count" id="gcount"></span></div>' +
      '<div class="section"><div id="glist" class="card pad-sm"></div></div>' +
      '<div class="dash-cols"><article class="card"><div class="card-head"><h2 class="t-h2">Department view</h2></div><div id="gdept-view"></div></article>' +
      '<article class="card"><div class="card-head"><h2 class="t-h2">Most gapped skills</h2></div><div id="gskill-view"></div></article></div>' +
      '</div>';
    return {
      title: 'Skill gaps', html: html,
      mount: function (root) {
        function refresh() {
          var list = filtered();
          root.querySelector('#gcount').textContent = list.length + ' record' + (list.length === 1 ? '' : 's');
          root.querySelector('#glist').innerHTML = list.length ? list.map(function (g) {
            var e = Store.emp(g.employeeId), s = Store.skill(g.skillId);
            return '<div class="gaprow"><span class="who">' + UI.avatar(e, 'sm') + '<span class="nm" title="' + UI.esc(e.name) + '"><a href="#/people/' + e.id + '">' + UI.esc(e.name) + '</a></span><span class="t-caption mut">' + UI.esc(e.dept) + '</span></span>' +
              '<span class="row wrap">' + UI.chipCat(s.cat, true) + '<span class="t-sm" style="font-weight:600">' + UI.esc(s.name) + '</span></span>' +
              UI.gapLine(g.current, g.expected, g.sev) +
              '<span class="row wrap">' + UI.chipSev(g.sev) + '<span class="t-caption mut">' + UI.fmtDate(g.date) + '</span></span></div>';
          }).join('') : UI.empty('check', 'No gaps match these filters', 'Widen the severity or clear the search to see more records.');
          var depts = Store.departments().map(function (d) { var s = Store.deptStats(d); return { d: d, n: s.gaps.length, c: s.critical, e: s.employees, a: s.assessed }; });
          var max = Math.max.apply(null, depts.map(function (x) { return x.n; }).concat([1]));
          root.querySelector('#gdept-view').innerHTML = depts.map(function (x) {
            return '<div class="deptgap"><span class="t-sm" style="font-weight:600">' + UI.esc(x.d) + '</span>' +
              '<span class="track" style="height:8px;background:var(--bg-sunken);border-radius:999px;overflow:hidden"><i style="display:block;height:100%;width:' + Math.round(x.n / max * 100) + '%;background:' + (x.c ? 'var(--warning)' : 'var(--accent)') + '"></i></span>' +
              '<span class="t-mono mut">' + x.n + ' open</span>' + (x.c ? UI.chip(x.c + ' critical', 'chip-error', true) : UI.chip('0 critical', 'chip-neutral', true)) + '</div>';
          }).join('');
          root.querySelector('#gskill-view').innerHTML = Store.mostGappedSkills(6).map(function (m) {
            var s = Store.skill(m.skillId);
            return '<div class="gaprow" style="grid-template-columns:1fr auto auto"><span class="t-sm" style="font-weight:600">' + UI.esc(s.name) + ' <span class="mut t-caption">· ' + UI.esc(Store.cat(s.cat).name) + '</span></span>' +
              '<span class="t-caption mut">' + m.n + ' employee' + (m.n === 1 ? '' : 's') + ' · avg gap ' + (Math.round(m.total / m.n * 10) / 10) + '</span>' +
              UI.chip(m.worst >= 3 ? 'Critical' : m.worst === 2 ? 'Required' : 'Monitor', m.worst >= 3 ? 'chip-error' : m.worst === 2 ? 'chip-warning' : 'chip-info', true) + '</div>';
          }).join('') || '<p class="sec">No gaps recorded yet.</p>';
        }
        UI.withLatency('gaps', root, function (loading) {
          if (loading) { root.querySelector('#glist').innerHTML = UI.skRows(6); return; }
          refresh();
        });
        root.querySelector('#gq').addEventListener('input', UI.debounce(function (e) { f.q = e.target.value; refresh(); }, 180));
        root.querySelector('#gdept').addEventListener('change', function (e) { f.dept = e.target.value; refresh(); });
        root.querySelector('#grole').addEventListener('change', function (e) { f.role = e.target.value; refresh(); });
        root.querySelector('#gsev').addEventListener('change', function (e) { f.sev = e.target.value; refresh(); });
      }
    };
  }
  return { render: render };
})();
