/* App shell: nav, search, view-as, boot */
window.DEMO_SELF = 'EMP-1001';

window.App = (function () {
  var NAV = [
    { id: 'dashboard', label: 'Dashboard', hash: '#/dashboard', views: ['evaluator', 'hr', 'employee'] },
    { id: 'people', label: 'Employees', hash: '#/people', views: ['evaluator', 'hr'], employeeLabel: 'My Growth', employeeHash: '#/people/' + window.DEMO_SELF },
    { id: 'skills', label: 'Skills', hash: '#/skills', views: ['evaluator', 'hr'] },
    { id: 'assessments', label: 'Assessments', hash: '#/assessments', views: ['evaluator', 'hr', 'employee'] },
    { id: 'gaps', label: 'Skill Gaps', hash: '#/gaps', views: ['evaluator', 'hr'] },
    { id: 'development', label: 'Development', hash: '#/development', views: ['evaluator', 'hr', 'employee'] },
    { id: 'reports', label: 'Reports', hash: '#/reports', views: ['evaluator', 'hr', 'employee'] }
  ];
  var ACTIVE = { dashboard: 'dashboard', people: 'people', profile: 'people', skills: 'skills', assessments: 'assessments', wizard: 'assessments', gaps: 'gaps', development: 'development', reports: 'reports', report: 'reports', settings: '' };

  function navFor(view) {
    return NAV.filter(function (n) { return n.views.indexOf(view) > -1; }).map(function (n) {
      if (view === 'employee' && n.employeeLabel) return { id: n.id, label: n.employeeLabel, hash: n.employeeHash };
      return n;
    });
  }

  function refreshNav(route) {
    var view = Store.state.viewAs;
    var active = ACTIVE[route.page];
    var html = navFor(view).map(function (n) {
      return '<a href="' + n.hash + '"' + (n.id === active ? ' aria-current="page"' : '') + '>' + UI.esc(n.label) + '</a>';
    }).join('');
    document.getElementById('tabs').innerHTML = html;
    document.getElementById('drawertabs').innerHTML = navFor(view).concat(view === 'hr' ? [{ id: 'settings', label: 'Settings', hash: '#/settings' }] : []).map(function (n) {
      return '<li><a href="' + n.hash + '"' + (n.id === active ? ' aria-current="page"' : '') + '>' + UI.esc(n.label) + '</a></li>';
    }).join('');
  }

  /* ---------- global search ---------- */
  var selIdx = -1, results = [];
  function openSearch() {
    var w = document.getElementById('searchwrap');
    w.hidden = false;
    var q = document.getElementById('globalq');
    q.value = ''; renderResults('');
    q.focus();
  }
  function closeSearch() { document.getElementById('searchwrap').hidden = true; selIdx = -1; }
  function search(q) {
    q = q.trim().toLowerCase();
    if (!q) return [];
    var out = [];
    Store.state.employees.forEach(function (e) {
      var r = Store.role(e.role);
      if ((e.name + ' ' + e.id + ' ' + e.dept + ' ' + (r ? r.title : '')).toLowerCase().indexOf(q) > -1)
        out.push({ grp: 'Employees', label: e.name, sub: e.id + ' · ' + e.dept, hash: '#/people/' + e.id });
    });
    Store.state.skills.forEach(function (s) {
      var c = Store.cat(s.cat);
      if ((s.name + ' ' + c.name).toLowerCase().indexOf(q) > -1)
        out.push({ grp: 'Skills', label: s.name, sub: c.name + ' · used in ' + Store.skillUsage(s.id).inRoles + ' roles', hash: '#/skills?q=' + encodeURIComponent(s.name) });
    });
    Store.departments().forEach(function (d) {
      if (d.toLowerCase().indexOf(q) > -1) out.push({ grp: 'Departments', label: d, sub: Store.state.employees.filter(function (e) { return e.dept === d; }).length + ' employees', hash: '#/people?dept=' + encodeURIComponent(d) });
    });
    Store.state.roles.forEach(function (r) {
      if (r.title.toLowerCase().indexOf(q) > -1) out.push({ grp: 'Roles', label: r.title, sub: Object.keys(r.exp).length + ' expected skills', hash: '#/people?role=' + encodeURIComponent(r.id) });
    });
    Store.state.assessments.forEach(function (a) {
      var e = Store.emp(a.employeeId);
      if ((a.id + ' ' + a.cycle + ' ' + (e ? e.name : '')).toLowerCase().indexOf(q) > -1)
        out.push({ grp: 'Assessments', label: a.id + ' · ' + (e ? e.name : ''), sub: a.cycle + ' · ' + a.status, hash: a.status === 'draft' ? '#/assess/' + a.id : '#/report/employee/' + a.employeeId });
    });
    return out.slice(0, 24);
  }
  function renderResults(q) {
    var box = document.getElementById('searchresults');
    results = search(q); selIdx = -1;
    if (!q.trim()) { box.innerHTML = '<div class="empty">Type to search employees, skills, departments, roles and assessments.</div>'; return; }
    if (!results.length) { box.innerHTML = '<div class="empty">No matches for “' + UI.esc(q) + '”. Try a name, skill or department.</div>'; return; }
    var html = '', grp = '';
    results.forEach(function (r, i) {
      if (r.grp !== grp) { grp = r.grp; html += '<div class="grp">' + grp + '</div>'; }
      html += '<button role="option" data-i="' + i + '" aria-selected="false">' + UI.icon('search', 14) + '<span style="flex:1;min-width:0"><span style="display:block;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + UI.esc(r.label) + '</span><span class="t-caption mut">' + UI.esc(r.sub) + '</span></span></button>';
    });
    box.innerHTML = html;
  }
  function bindSearch() {
    var q = document.getElementById('globalq');
    q.addEventListener('input', UI.debounce(function () { renderResults(q.value); }, 160));
    q.addEventListener('keydown', function (e) {
      var box = document.getElementById('searchresults');
      var opts = box.querySelectorAll('button[data-i]');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        if (!opts.length) return;
        e.preventDefault();
        selIdx = e.key === 'ArrowDown' ? Math.min(selIdx + 1, opts.length - 1) : Math.max(selIdx - 1, 0);
        opts.forEach(function (o, i) { o.classList.toggle('sel', i === selIdx); o.setAttribute('aria-selected', i === selIdx ? 'true' : 'false'); });
        opts[selIdx].scrollIntoView({ block: 'nearest' });
      }
      if (e.key === 'Enter' && opts.length) {
        var i = selIdx > -1 ? selIdx : 0;
        location.hash = results[i].hash; closeSearch();
      }
      if (e.key === 'Escape') closeSearch();
    });
    document.getElementById('searchresults').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-i]'); if (!b) return;
      location.hash = results[parseInt(b.dataset.i, 10)].hash; closeSearch();
    });
    document.getElementById('searchbtn').addEventListener('click', openSearch);
    document.getElementById('searchclose').addEventListener('click', closeSearch);
    document.getElementById('searchwrap').addEventListener('mousedown', function (e) { if (e.target.id === 'searchwrap') closeSearch(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === '/' && !/^(input|textarea|select)$/i.test(document.activeElement.tagName)) { e.preventDefault(); openSearch(); }
    });
  }

  function bindChrome() {
    var menubtn = document.getElementById('menubtn'), drawer = document.getElementById('drawer');
    menubtn.addEventListener('click', function () {
      var open = drawer.hidden;
      drawer.hidden = !open;
      menubtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    drawer.addEventListener('click', function (e) { if (e.target.closest('a')) { drawer.hidden = true; menubtn.setAttribute('aria-expanded', 'false'); } });

    var userbtn = document.getElementById('userbtn'), usermenu = document.getElementById('usermenu');
    userbtn.addEventListener('click', function () {
      var open = usermenu.hidden;
      usermenu.hidden = !open; userbtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('click', function (e) {
      if (!e.target.closest('.usermenu')) { usermenu.hidden = true; userbtn.setAttribute('aria-expanded', 'false'); }
    });
    document.getElementById('resetdemo').addEventListener('click', function () {
      UI.confirmDialog({ title: 'Reset demo data?', text: 'All local changes (employees, assessments, plans) will be replaced with the original seed data.', confirmLabel: 'Reset data', danger: true }).then(function (yes) {
        if (!yes) return;
        Store.reset();
        UI.toast('Demo data reset to seed.', 'info');
        Router.render();
      });
    });

    var vas = document.getElementById('viewas');
    vas.value = Store.state.viewAs;
    vas.addEventListener('change', function () {
      Store.mutate(function (s) { s.viewAs = vas.value; });
      UI.toast('Now viewing as ' + vas.options[vas.selectedIndex].text + '.', 'info');
      Router.render();
    });
  }

  function init() {
    Store.load();
    bindChrome();
    bindSearch();
    Router.start();
  }

  return { init: init, refreshNav: refreshNav };
})();

document.addEventListener('DOMContentLoaded', App.init);
