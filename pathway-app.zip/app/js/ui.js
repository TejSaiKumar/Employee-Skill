/* UI kit — Pathway components (spec §4) */
window.UI = (function () {
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    var p = String(iso).slice(0, 10).split('-');
    return parseInt(p[2], 10) + ' ' + MONTHS[parseInt(p[1], 10) - 1] + ' ' + p[0];
  }
  function nowTime() {
    var d = new Date();
    return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
  }
  function initials(name) {
    return String(name).trim().split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase();
  }
  function debounce(fn, ms) {
    var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  }

  var ICONS = {
    check: '<path d="M5 12.5l4.2 4.2L19 7"/>',
    tick: '<path d="M5 12.5l4.2 4.2L19 7"/>',
    alert: '<path d="M12 8v5"/><circle cx="12" cy="16.5" r=".6" fill="currentColor"/><path d="M10.3 3.9 2.6 17.4a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="8" r=".6" fill="currentColor"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/>',
    trash: '<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/>',
    print: '<path d="M7 8V4h10v4M7 17H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="7" y="14" width="10" height="7" rx="1"/>',
    chev: '<path d="m6 9 6 6 6-6"/>',
    flag: '<path d="M5 21V4c4-2 8 2 14 0v10c-6 2-10-2-14 0"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 5-5.5 8-5.5S18.5 17 20 21"/>',
    cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    flat: '<path d="M5 12h14"/>',
    doc: '<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/>',
    spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>'
  };
  function icon(name, size) {
    size = size || 16;
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  }

  /* ---------- chips ---------- */
  function chipCat(catId, sm) {
    var c = Store.cat(catId); if (!c) return '';
    return '<span class="chip chip-cat' + (sm ? ' sm' : '') + '" style="--cat-t:var(--cat-' + catId + '-t);--cat-i:var(--cat-' + catId + '-i)"><span class="cdot"></span>' + esc(c.name) + '</span>';
  }
  function chip(text, cls, sm, ic) {
    return '<span class="chip ' + cls + (sm ? ' sm' : '') + '">' + (ic ? icon(ic, 12) : '') + esc(text) + '</span>';
  }
  function chipAssessStatus(st) {
    return st === 'submitted' ? chip('Submitted', 'chip-success', true, 'check') : chip('Draft', 'chip-info', true, 'cal');
  }
  function chipSev(sev) {
    if (sev === 'meet') return chip('Meets expectation', 'chip-success', true, 'check');
    if (sev === 'exceeds') return chip('Exceeds expectation', 'chip-info', true, 'up');
    if (sev === 'monitor') return chip('Monitor · 1 level', 'chip-warning', true, 'info');
    if (sev === 'required') return chip('Development required', 'chip-warning', true, 'alert');
    return chip('Critical gap', 'chip-error', true, 'alert');
  }
  function chipRecStatus(st) {
    if (st === 'Completed') return chip('Completed', 'chip-success', true, 'check');
    if (st === 'In Progress') return chip('In Progress', 'chip-info', true);
    return chip('Not Started', 'chip-neutral', true);
  }
  function chipPriority(p) {
    if (p === 'High') return chip('High priority', 'chip-warning', true);
    if (p === 'Medium') return chip('Medium priority', 'chip-info', true);
    return chip('Low priority', 'chip-neutral', true);
  }

  /* ---------- avatar ---------- */
  function avatar(e, sizeCls) {
    var cls = 'avatar' + (sizeCls ? ' ' + sizeCls : '');
    return '<span class="' + cls + '" aria-hidden="true">' + esc(initials(e.name)) + '</span>';
  }

  /* ---------- proficiency dots ---------- */
  function dotsRead(cur, expected) {
    var s = Store.state.levels;
    var html = '<span class="dots ro" role="img" aria-label="Proficiency ' + (cur || 0) + ' of 5' + (cur ? ' (' + s[cur - 1].label + ')' : ' (not rated)') + '">';
    for (var n = 1; n <= 5; n++) html += '<span class="dot' + (cur && n <= cur ? ' fill' : '') + '"></span>';
    html += '</span>';
    if (expected) {
      html += '<span class="expectline"><span class="dots ro" aria-hidden="true"><span class="dot ghost"></span></span>Role expects: ' + esc(s[expected - 1].label) + '</span>';
    }
    return html;
  }
  function dotsEdit(name, cur, legend) {
    var s = Store.state.levels;
    var html = '<fieldset class="dotsfield"><legend class="sr">' + esc(legend) + '</legend><div class="dots">';
    for (var n = 1; n <= 5; n++) {
      html += '<label class="dotlbl"><input type="radio" class="sr-dot" name="' + esc(name) + '" value="' + n + '"' + (cur === n ? ' checked' : '') + '>' +
        '<span class="dot' + (cur && n < cur ? ' fill' : '') + '" aria-hidden="true"></span>' +
        '<span class="sr">' + n + ' — ' + esc(s[n - 1].label) + '</span></label>';
    }
    html += '</div></fieldset>';
    return html;
  }
  function levelWord(n) {
    var l = Store.level(n);
    return l ? l.label : 'Not rated';
  }

  /* ---------- gap bracket ---------- */
  function gapSentence(gap, sev) {
    if (gap < 0) return 'Exceeds by ' + Math.abs(gap) + (Math.abs(gap) === 1 ? ' level' : ' levels');
    if (gap === 0) return 'Meets role expectation';
    if (gap === 1) return 'Gap: 1 level — development suggested';
    if (sev === 'critical') return 'Critical gap: ' + gap + ' levels — priority development';
    return 'Gap: ' + gap + ' levels — development plan required';
  }
  function gapLine(cur, expected, sev, withSentence) {
    var gap = expected - cur;
    var cls = gap === 0 ? 'meet' : (gap < 0 ? 'exceed' : '');
    var html = '<span class="gapline ' + cls + '">';
    html += '<span class="dots ro" aria-hidden="true">';
    for (var n = 1; n <= 5; n++) html += '<span class="dot' + (n <= cur ? ' fill' : '') + '"></span>';
    html += '</span>';
    if (gap > 0) {
      html += '<svg width="22" height="14" viewBox="0 0 22 14" aria-hidden="true"><path d="M1 1v6h20V1" fill="none" stroke="currentColor" stroke-width="2"/></svg>' +
        '<span class="dots ro" aria-hidden="true"><span class="dot ghost"></span></span>';
    }
    if (withSentence !== false) html += '<span>' + esc(gapSentence(gap, sev)) + '</span>';
    else html += '<span class="sr">' + esc(gapSentence(gap, sev)) + '</span>';
    html += '</span>';
    return html;
  }

  /* ---------- spark ---------- */
  function spark(prev, cur) {
    if (prev == null) return '<span class="spark">' + icon('spark', 14) + ' first assessment</span>';
    var d = Math.round((cur - prev) * 10) / 10;
    if (d === 0) return '<span class="spark"><svg width="46" height="16" viewBox="0 0 46 16" aria-hidden="true"><line x1="5" y1="8" x2="41" y2="8" stroke="#5B6F82" stroke-width="2"/><circle cx="5" cy="8" r="3" fill="#5B6F82"/><circle cx="41" cy="8" r="3" fill="#5B6F82"/></svg> no change</span>';
    var up = d > 0, col = up ? '#15803D' : '#B45309';
    var y1 = up ? 12 : 4, y2 = up ? 4 : 12;
    return '<span class="spark"><svg width="46" height="16" viewBox="0 0 46 16" aria-hidden="true"><line x1="5" y1="' + y1 + '" x2="41" y2="' + y2 + '" stroke="' + col + '" stroke-width="2"/><circle cx="5" cy="' + y1 + '" r="3" fill="' + col + '"/><circle cx="41" cy="' + y2 + '" r="3" fill="' + col + '"/></svg>' +
      (up ? '▲ +' : '▼ ') + d + ' since last cycle</span>';
  }

  /* ---------- progress ---------- */
  function progress(rated, total, cls) {
    var pct = total ? Math.round(rated / total * 100) : 0;
    return '<div class="progress' + (cls ? ' ' + cls : '') + '" role="progressbar" aria-valuenow="' + rated + '" aria-valuemin="0" aria-valuemax="' + total + '" aria-label="' + rated + ' of ' + total + ' skills rated"><i style="width:' + pct + '%"></i></div>' +
      '<span class="t-caption mut">' + rated + ' of ' + total + ' skills · ' + pct + '%</span>';
  }

  /* ---------- competency wheel ---------- */
  var SHORT = { tech: 'Tech', beh: 'Behavioral', mgmt: 'Mgmt', lead: 'Leadership', comp: 'Compliance', soc: 'Social' };
  function wheelPoint(i, r) {
    var a = (-90 + i * 60) * Math.PI / 180;
    return [130 + r * Math.cos(a), 130 + r * Math.sin(a)];
  }
  function poly(values, r) {
    return values.map(function (v, i) {
      var p = wheelPoint(i, r * (v == null ? 0 : v) / 5);
      return p[0].toFixed(1) + ',' + p[1].toFixed(1);
    }).join(' ');
  }
  function wheel(valuesByCat, size) {
    size = size || 260;
    var cats = Store.state.categories;
    var vals = cats.map(function (c) { return valuesByCat ? valuesByCat[c.id] : null; });
    var has = vals.some(function (v) { return v != null; });
    var s = '<div class="wheelwrap"><svg class="wheel-svg" width="' + size + '" height="' + size + '" viewBox="0 0 260 260" role="img" aria-label="' + (has ? 'Competency wheel by category' : 'Not assessed yet') + '">';
    s += '<polygon points="' + poly([5, 5, 5, 5, 5, 5], 86) + '" fill="var(--bg-sunken)" opacity=".55"/>';
    for (var v = 1; v <= 5; v++) s += '<polygon points="' + poly([v, v, v, v, v, v], 86) + '" fill="none" stroke="#D8E4EC" stroke-width="1"/>';
    cats.forEach(function (c, i) {
      var p1 = wheelPoint(i, 86), p2 = wheelPoint(i, 8);
      s += '<line x1="' + p2[0] + '" y1="' + p2[1] + '" x2="' + p1[0] + '" y2="' + p1[1] + '" stroke="#D8E4EC" stroke-width="1"/>';
    });
    if (has) {
      s += '<polygon points="' + poly(vals.map(function (v) { return v == null ? 0 : v; }), 86) + '" fill="var(--accent)" fill-opacity=".22" stroke="var(--accent)" stroke-width="2"/>';
      vals.forEach(function (v, i) {
        if (v == null) return;
        var p = wheelPoint(i, 86 * v / 5);
        s += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3.4" fill="var(--accent)"/>';
      });
    }
    cats.forEach(function (c, i) {
      var p = wheelPoint(i, 108);
      var anchor = Math.abs(p[0] - 130) < 12 ? 'middle' : (p[0] > 130 ? 'start' : 'end');
      var val = vals[i] == null ? '—' : vals[i];
      s += '<text x="' + p[0].toFixed(1) + '" y="' + (p[1] + 3).toFixed(1) + '" text-anchor="' + anchor + '" font-size="11" font-weight="600" fill="#46586A">' + esc(SHORT[c.id]) + ' ' + val + '</text>';
    });
    if (!has) s += '<text x="130" y="134" text-anchor="middle" font-size="13" fill="#5B6F82">Not assessed yet</text>';
    s += '</svg>';
    /* print-equivalent table (revealed by print.css) */
    s += '<div class="wheel-table"><table><caption class="sr">Average proficiency by category</caption><tr><th>Category</th><th>Average level (1–5)</th></tr>';
    cats.forEach(function (c, i) {
      s += '<tr><td>' + esc(c.name) + '</td><td>' + (vals[i] == null ? 'Not assessed' : vals[i]) + '</td></tr>';
    });
    s += '</table></div></div>';
    return s;
  }
  function catAveragesFor(empId, onlySubmitted) {
    var a = Store.latestAssessment(empId, onlySubmitted);
    if (!a) return null;
    var out = {};
    Store.itemsList(a).forEach(function (i) {
      var s = Store.skill(i.skillId); if (!s || !i.level) return;
      out[s.cat] = out[s.cat] || { sum: 0, n: 0 };
      out[s.cat].sum += i.level; out[s.cat].n++;
    });
    var res = {};
    Object.keys(out).forEach(function (k) { res[k] = Math.round(out[k].sum / out[k].n * 10) / 10; });
    return Object.keys(res).length ? res : null;
  }

  /* ---------- stat strip & distribution ---------- */
  function statStrip(cells) {
    return '<div class="statstrip">' + cells.map(function (c) {
      return '<div class="cell' + (c.alert ? ' alert' : '') + '"><div class="v">' + esc(c.v) + '</div><div class="k">' + esc(c.k) + '</div></div>';
    }).join('') + '</div>';
  }
  function dist(rows) {
    var max = Math.max.apply(null, rows.map(function (r) { return r.n; }).concat([1]));
    return '<div class="dist">' + rows.map(function (r) {
      return '<div class="rowline"><span class="t-sm sec">' + esc(r.label) + '</span><span class="track"><i style="width:' + Math.round(r.n / max * 100) + '%"></i></span><span class="n">' + r.n + '</span></div>';
    }).join('') + '</div>';
  }

  /* ---------- empty & skeleton ---------- */
  function empty(ic, title, text, cta) {
    return '<div class="empty"><span class="ic">' + icon(ic, 20) + '</span><h3>' + esc(title) + '</h3><p>' + esc(text) + '</p>' + (cta || '') + '</div>';
  }
  function skPerson() {
    return '<div class="card pad-sm" style="display:flex;gap:12px"><span class="sk" style="width:40px;height:40px;border-radius:50%;flex:none"></span><span style="flex:1;display:flex;flex-direction:column;gap:8px"><span class="sk" style="height:12px;width:70%"></span><span class="sk" style="height:10px;width:45%"></span><span class="sk" style="height:8px"></span></span></div>';
  }
  function skRows(n) {
    var s = '<div class="card pad-sm stack">';
    for (var i = 0; i < n; i++) s += '<span class="sk" style="height:14px;width:' + (90 - i * 7) + '%"></span>';
    return s + '</div>';
  }

  /* ---------- toast ---------- */
  function toast(msg, type, action) {
    type = type || 'success';
    var region = document.getElementById('toasts');
    var el = document.createElement('div');
    el.className = 'toast ' + type;
    el.innerHTML = '<span class="ic">' + icon(type === 'success' ? 'check' : type === 'error' ? 'alert' : 'info', 12) + '</span><span class="grow">' + esc(msg) + '</span>';
    if (action) {
      var b = document.createElement('button');
      b.className = 'btn sm btn-secondary';
      b.textContent = action.label;
      b.addEventListener('click', function () { action.onClick(); close(); });
      el.appendChild(b);
    }
    var x = document.createElement('button');
    x.className = 'iconbtn sm'; x.setAttribute('aria-label', 'Dismiss notification');
    x.innerHTML = icon('close', 14);
    x.addEventListener('click', close);
    el.appendChild(x);
    region.appendChild(el);
    while (region.children.length > 2) region.removeChild(region.firstChild);
    var t = setTimeout(close, type === 'error' ? 8000 : 4200);
    function close() { clearTimeout(t); el.classList.add('out'); setTimeout(function () { el.remove(); }, 200); }
  }

  /* ---------- modal / confirm ---------- */
  var lastFocus = null;
  function openModal(opts) {
    lastFocus = document.activeElement;
    var root = document.getElementById('modalroot');
    var wrap = document.createElement('div');
    wrap.className = 'overlay';
    wrap.innerHTML =
      '<div class="modal' + (opts.wide ? ' wide' : '') + '" role="dialog" aria-modal="true" aria-labelledby="mdl-t">' +
      '<div class="modal-head"><h2 id="mdl-t" class="t-h2">' + esc(opts.title) + '</h2>' +
      '<button class="iconbtn" data-close aria-label="Close dialog">' + icon('close', 18) + '</button></div>' +
      '<div class="modal-body">' + (opts.body || '') + '</div>' +
      (opts.footer ? '<div class="modal-foot">' + opts.footer + '</div>' : '') +
      '</div>';
    root.appendChild(wrap);
    var panel = wrap.querySelector('.modal');
    function close() {
      wrap.remove();
      document.removeEventListener('keydown', onKey, true);
      if (lastFocus) lastFocus.focus();
    }
    function onKey(e) {
      if (e.key === 'Escape') { e.stopPropagation(); close(); if (opts.onClose) opts.onClose(); }
      if (e.key === 'Tab') {
        var f = panel.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])');
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    }
    document.addEventListener('keydown', onKey, true);
    wrap.addEventListener('mousedown', function (e) { if (e.target === wrap) { close(); if (opts.onClose) opts.onClose(); } });
    wrap.querySelector('[data-close]').addEventListener('click', function () { close(); if (opts.onClose) opts.onClose(); });
    setTimeout(function () {
      var f = panel.querySelector('input,select,textarea,button.btn-primary,button');
      if (f) f.focus();
    }, 30);
    if (opts.onMount) opts.onMount(panel, close);
    return { close: close, panel: panel };
  }
  function confirmDialog(opts) {
    return new Promise(function (resolve) {
      var m = openModal({
        title: opts.title,
        body: '<p class="t-body-lg sec" style="margin:0">' + esc(opts.text) + '</p>',
        footer: '<button class="btn btn-ghost" data-no>Cancel</button><button class="btn ' + (opts.danger ? 'btn-destruct' : 'btn-primary') + '" data-yes>' + esc(opts.confirmLabel || 'Confirm') + '</button>',
        onMount: function (panel, close) {
          panel.querySelector('[data-no]').addEventListener('click', function () { close(); resolve(false); });
          panel.querySelector('[data-yes]').addEventListener('click', function () { close(); resolve(true); });
        },
        onClose: function () { resolve(false); }
      });
      void m;
    });
  }

  /* ---------- simulated first-load latency ---------- */
  var seen = {};
  function firstLoad(key) {
    if (seen[key]) return false;
    seen[key] = true; return true;
  }
  function withLatency(key, container, render) {
    if (!firstLoad(key)) { render(); return; }
    render(true);
    setTimeout(render, 340);
  }

  return {
    esc: esc, fmtDate: fmtDate, nowTime: nowTime, initials: initials, debounce: debounce, icon: icon,
    chipCat: chipCat, chip: chip, chipAssessStatus: chipAssessStatus, chipSev: chipSev,
    chipRecStatus: chipRecStatus, chipPriority: chipPriority,
    avatar: avatar, dotsRead: dotsRead, dotsEdit: dotsEdit, levelWord: levelWord,
    gapSentence: gapSentence, gapLine: gapLine, spark: spark, progress: progress,
    wheel: wheel, catAveragesFor: catAveragesFor, statStrip: statStrip, dist: dist,
    empty: empty, skPerson: skPerson, skRows: skRows, toast: toast,
    openModal: openModal, confirmDialog: confirmDialog, withLatency: withLatency
  };
})();
