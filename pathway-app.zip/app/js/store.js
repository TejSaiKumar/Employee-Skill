/* Store: persistence + domain logic */
window.Store = (function () {
  var KEY = 'pathway.v1';
  var state = null;

  function seed() { return JSON.parse(JSON.stringify(window.SEED)); }

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.version === 1) { state = parsed; return; }
      }
    } catch (e) { /* corrupted or unavailable storage — fall through to seed */ }
    state = seed();
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); return true; }
    catch (e) {
      if (window.UI) UI.toast('Could not save locally — storage unavailable.', 'error');
      return false;
    }
  }

  function mutate(fn) { fn(state); save(); }

  function reset() { state = seed(); save(); }

  /* lookups */
  function emp(id) { return state.employees.filter(function (e) { return e.id === id; })[0] || null; }
  function skill(id) { return state.skills.filter(function (s) { return s.id === id; })[0] || null; }
  function cat(id) { return state.categories.filter(function (c) { return c.id === id; })[0] || null; }
  function role(id) { return state.roles.filter(function (r) { return r.id === id; })[0] || null; }
  function level(id) { return state.levels.filter(function (l) { return l.id === id; })[0] || null; }
  function assessment(id) { return state.assessments.filter(function (a) { return a.id === id; })[0] || null; }
  function managerName(e) { var m = e.managerId && emp(e.managerId); return m ? m.name : 'Executive team'; }

  /* role expectations for an employee: [{skillId, expected, critical}] */
  function expectations(empId) {
    var e = emp(empId); if (!e) return [];
    var r = role(e.role); if (!r) return [];
    return Object.keys(r.exp).map(function (sid) {
      return { skillId: sid, expected: r.exp[sid], critical: (r.critical || []).indexOf(sid) > -1 };
    });
  }

  function scopeSkills(a) {
    /* skills in the assessment's selected categories that the role expects */
    var exps = expectations(a.employeeId);
    return exps.filter(function (x) {
      var s = skill(x.skillId); return s && a.categoryIds.indexOf(s.cat) > -1;
    });
  }

  function itemsList(a) {
    return scopeSkills(a).map(function (x) {
      var it = a.items[x.skillId] || {};
      return {
        skillId: x.skillId, expected: x.expected, critical: x.critical,
        level: it.level || null, comment: it.comment || ''
      };
    });
  }

  function coverage(a) {
    var list = itemsList(a);
    var rated = list.filter(function (i) { return i.level; }).length;
    return { rated: rated, total: list.length, pct: list.length ? Math.round(rated / list.length * 100) : 0 };
  }

  function sevOf(gap, critical) {
    if (gap < 0) return 'exceeds';
    if (gap === 0) return 'meet';
    if (gap === 1) return 'monitor';
    if (gap >= 3 || (gap >= 2 && critical)) return 'critical';
    return 'required';
  }

  /* gaps from the latest assessment that has ratings (draft or submitted) */
  function latestAssessment(empId, onlySubmitted) {
    var list = state.assessments.filter(function (a) {
      return a.employeeId === empId && (!onlySubmitted || a.status === 'submitted');
    });
    list.sort(function (a, b) { return (b.submittedAt || b.updatedAt).localeCompare(a.submittedAt || a.updatedAt); });
    return list[0] || null;
  }

  function assessmentsFor(empId) {
    return state.assessments.filter(function (a) { return a.employeeId === empId; })
      .sort(function (a, b) { return (b.submittedAt || b.updatedAt).localeCompare(a.submittedAt || a.updatedAt); });
  }

  function gapsFor(empId) {
    var a = latestAssessment(empId);
    if (!a) return { assessment: null, gaps: [] };
    var gaps = itemsList(a).filter(function (i) { return i.level; }).map(function (i) {
      var gap = i.expected - i.level;
      return {
        employeeId: empId, skillId: i.skillId, current: i.level, expected: i.expected,
        gap: gap, sev: sevOf(gap, i.critical), assessmentId: a.id, date: a.submittedAt || a.updatedAt
      };
    });
    return { assessment: a, gaps: gaps };
  }

  function openGaps(empId) {
    return gapsFor(empId).gaps.filter(function (g) { return g.gap >= 1; });
  }

  function recsFor(empId) {
    return state.recommendations.filter(function (r) { return r.employeeId === empId; });
  }

  /* rule-based suggestions for gaps without an active plan */
  var SUGGEST = {
    tech: function (s) { return 'Structured training course on ' + s.name; },
    beh:  function (s) { return 'Guided practice with feedback in team rituals (' + s.name + ')'; },
    mgmt: function (s) { return 'Stretch assignment: own a ' + s.name + '-heavy initiative end-to-end'; },
    lead: function (s) { return 'Mentorship with a senior leader focused on ' + s.name; },
    comp: function (s) { return 'Certification pathway for ' + s.name; },
    soc:  function (s) { return 'Volunteer lead for the ' + s.name + ' initiative this quarter'; }
  };
  var SUGGEST_TYPE = { tech: 'Training', beh: 'Practice', mgmt: 'Stretch assignment', lead: 'Mentorship', comp: 'Certification', soc: 'Practice' };

  function suggestionsFor(empId) {
    var gaps = openGaps(empId);
    var active = recsFor(empId).filter(function (r) { return r.status !== 'Completed'; }).map(function (r) { return r.skillId; });
    return gaps.filter(function (g) { return active.indexOf(g.skillId) === -1; }).map(function (g) {
      var s = skill(g.skillId);
      return {
        employeeId: empId, skillId: g.skillId, current: g.current, expected: g.expected, gap: g.gap, sev: g.sev,
        action: SUGGEST[s.cat](s), type: SUGGEST_TYPE[s.cat],
        priority: g.sev === 'critical' ? 'High' : (g.sev === 'required' ? 'Medium' : 'Low'),
        weeks: g.gap * 3
      };
    });
  }

  /* org-level analytics */
  function orgStats() {
    var emps = state.employees;
    var submitted = state.assessments.filter(function (a) { return a.status === 'submitted' && a.cycle === state.cycle; });
    var drafts = state.assessments.filter(function (a) { return a.status === 'draft'; });
    var assessedIds = submitted.map(function (a) { return a.employeeId; });
    var pending = emps.length - assessedIds.length;
    var allGaps = [];
    emps.forEach(function (e) { allGaps = allGaps.concat(openGaps(e.id)); });
    var critical = allGaps.filter(function (g) { return g.sev === 'critical'; }).length;
    var needing = {};
    allGaps.forEach(function (g) { if (g.sev === 'required' || g.sev === 'critical') needing[g.employeeId] = true; });
    return {
      employees: emps.length,
      skills: state.skills.length,
      completed: submitted.length,
      pending: Math.max(0, pending) + drafts.length,
      critical: critical,
      needing: Object.keys(needing).length,
      gaps: allGaps
    };
  }

  function deptStats(dept) {
    var emps = state.employees.filter(function (e) { return e.dept === dept; });
    var gaps = [];
    var assessed = 0;
    emps.forEach(function (e) {
      var g = gapsFor(e.id);
      if (g.assessment && g.assessment.status === 'submitted') assessed++;
      gaps = gaps.concat(g.gaps.filter(function (x) { return x.gap >= 1; }));
    });
    return { employees: emps.length, assessed: assessed, gaps: gaps, critical: gaps.filter(function (g) { return g.sev === 'critical'; }).length };
  }

  function departments() {
    var seen = [];
    state.employees.forEach(function (e) { if (seen.indexOf(e.dept) === -1) seen.push(e.dept); });
    return seen.sort();
  }

  function proficiencyDist() {
    var counts = {};
    state.levels.forEach(function (l) { counts[l.id] = 0; });
    state.assessments.forEach(function (a) {
      if (a.status !== 'submitted') return;
      Object.keys(a.items).forEach(function (sid) {
        var lv = a.items[sid].level; if (lv && counts[lv] !== undefined) counts[lv]++;
      });
    });
    return state.levels.map(function (l) { return { id: l.id, label: l.label, n: counts[l.id] }; });
  }

  function categoryAverages(deptFilter) {
    return state.categories.map(function (c) {
      var sum = 0, n = 0;
      state.employees.forEach(function (e) {
        if (deptFilter && e.dept !== deptFilter) return;
        var a = latestAssessment(e.id, true); if (!a) return;
        itemsList(a).forEach(function (i) {
          var s = skill(i.skillId);
          if (s && s.cat === c.id && i.level) { sum += i.level; n++; }
        });
      });
      return { cat: c.id, name: c.name, avg: n ? Math.round(sum / n * 10) / 10 : null, n: n };
    });
  }

  function mostGappedSkills(limit) {
    var by = {};
    state.employees.forEach(function (e) {
      openGaps(e.id).forEach(function (g) {
        by[g.skillId] = by[g.skillId] || { skillId: g.skillId, n: 0, total: 0, worst: 0 };
        by[g.skillId].n++; by[g.skillId].total += g.gap;
        by[g.skillId].worst = Math.max(by[g.skillId].worst, g.gap);
      });
    });
    return Object.keys(by).map(function (k) { return by[k]; })
      .sort(function (a, b) { return b.n - a.n || b.total - a.total; }).slice(0, limit || 6);
  }

  function strongestSkills(limit) {
    var by = {};
    state.employees.forEach(function (e) {
      gapsFor(e.id).gaps.forEach(function (g) {
        if (g.gap <= 0 && g.current >= 4) {
          by[g.skillId] = (by[g.skillId] || 0) + 1;
        }
      });
    });
    return Object.keys(by).map(function (k) { return { skillId: k, n: by[k] }; })
      .sort(function (a, b) { return b.n - a.n; }).slice(0, limit || 6);
  }

  function skillUsage(skillId) {
    var inRoles = state.roles.filter(function (r) { return r.exp[skillId]; }).length;
    var rated = 0;
    state.assessments.forEach(function (a) { if (a.items[skillId] && a.items[skillId].level) rated++; });
    return { inRoles: inRoles, rated: rated };
  }

  function nextId(prefix, list) {
    var max = 0;
    list.forEach(function (x) {
      var n = parseInt(String(x.id).replace(/\D/g, ''), 10);
      if (!isNaN(n) && n > max) max = n;
    });
    return prefix + (max + 1);
  }

  function addEvent(type, text) {
    state.events.unshift({ date: new Date().toISOString().slice(0, 10), type: type, text: text });
    if (state.events.length > 40) state.events.length = 40;
  }

  return {
    get state() { return state; },
    load: load, save: save, mutate: mutate, reset: reset,
    emp: emp, skill: skill, cat: cat, role: role, level: level, assessment: assessment,
    managerName: managerName, expectations: expectations, scopeSkills: scopeSkills,
    itemsList: itemsList, coverage: coverage, sevOf: sevOf,
    latestAssessment: latestAssessment, assessmentsFor: assessmentsFor,
    gapsFor: gapsFor, openGaps: openGaps, recsFor: recsFor, suggestionsFor: suggestionsFor,
    orgStats: orgStats, deptStats: deptStats, departments: departments,
    proficiencyDist: proficiencyDist, categoryAverages: categoryAverages,
    mostGappedSkills: mostGappedSkills, strongestSkills: strongestSkills, skillUsage: skillUsage,
    nextId: nextId, addEvent: addEvent
  };
})();
