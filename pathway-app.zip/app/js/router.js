/* Hash router */
window.Router = (function () {
  var routes = [
    { pat: ['dashboard'], page: 'dashboard' },
    { pat: ['people'], page: 'people' },
    { pat: ['people', ':id'], page: 'profile' },
    { pat: ['skills'], page: 'skills' },
    { pat: ['assessments'], page: 'assessments' },
    { pat: ['assess', ':id'], page: 'wizard' },
    { pat: ['gaps'], page: 'gaps' },
    { pat: ['development'], page: 'development' },
    { pat: ['reports'], page: 'reports' },
    { pat: ['report', ':type', ':key'], page: 'report' },
    { pat: ['settings'], page: 'settings' }
  ];

  function parse() {
    var h = location.hash.replace(/^#\/?/, '');
    var parts = h ? h.split('/') : [];
    for (var i = 0; i < routes.length; i++) {
      var r = routes[i];
      if (r.pat.length !== parts.length) continue;
      var params = {}, ok = true;
      for (var j = 0; j < r.pat.length; j++) {
        if (r.pat[j][0] === ':') params[r.pat[j].slice(1)] = decodeURIComponent(parts[j]);
        else if (r.pat[j] !== parts[j]) { ok = false; break; }
      }
      if (ok) return { page: r.page, params: params };
    }
    return { page: 'dashboard', params: {} };
  }

  function go(hash) { location.hash = hash; }

  function render() {
    var r = parse();
    var page = window.Pages[r.page];
    var main = document.getElementById('main');
    if (!page) { page = window.Pages.dashboard; r = { page: 'dashboard', params: {} }; }

    /* role guards */
    var view = Store.state.viewAs;
    if (r.page === 'settings' && view !== 'hr') {
      UI.toast('Settings is available to HR admins in this demo.', 'info');
      go('#/dashboard'); return;
    }
    if (view === 'employee' && ['people', 'skills', 'gaps'].indexOf(r.page) > -1) {
      go('#/people/' + window.DEMO_SELF); return;
    }

    var out = page.render(r.params);
    document.title = out.title + ' — Pathway';
    main.innerHTML = out.html;
    if (window.App) App.refreshNav(r);
    if (out.mount) out.mount(main, r.params);
    main.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function start() {
    window.addEventListener('hashchange', render);
    if (!location.hash) location.hash = '#/dashboard';
    render();
  }

  return { start: start, render: render, go: go, parse: parse };
})();
